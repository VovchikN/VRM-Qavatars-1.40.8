#!/usr/bin/env python3
"""Actual render-target resize block with allocation/release spies; no Unity GPU."""
from pathlib import Path
import os,subprocess,tempfile
r=Path(__file__).resolve().parents[1]
t=(r/'src/MirrorManager.cpp').read_text();a=t.index('            // Changing the physical mirror size');b=t.index('        rendMat->SetFloat',a);block=t[a:b];block=block[:block.rfind('        }')]
code=r'''
#include <algorithm>
#include <cassert>
#include <iostream>
#include <memory>
#include <vector>
namespace UnityEngine {
enum class RenderTextureFormat {ARGB32};
struct RenderTexture {
 static inline int allocations=0,releases=0,destroys=0;static inline std::vector<std::unique_ptr<RenderTexture>> owned;
 int width,height;bool released=false;int get_width(){return width;}int get_height(){return height;}
 void Release(){assert(!released);released=true;++releases;}
 static RenderTexture* New_ctor(int w,int h,int,RenderTextureFormat){++allocations;owned.push_back(std::make_unique<RenderTexture>(RenderTexture{w,h}));return owned.back().get();}
};
struct Object {static void Destroy(RenderTexture* p){assert(p->released);++RenderTexture::destroys;}};
}
struct Camera {UnityEngine::RenderTexture* target=nullptr;auto get_targetTexture(){return target;}void set_targetTexture(UnityEngine::RenderTexture* p){target=p;}};
struct Material {UnityEngine::RenderTexture* tex=nullptr;void set_mainTexture(UnityEngine::RenderTexture* t){tex=t;}};
void resize(Camera* mirrorCamera,Material* rendMat,float aspect){
'''+block+r'''
}
int main(){using T=UnityEngine::RenderTexture;Camera camera;Material mat;
 resize(&camera,&mat,1);auto* first=camera.target;assert(T::allocations==1&&mat.tex==first);
 for(int i=0;i<100;++i)resize(&camera,&mat,1);assert(camera.target==first&&T::allocations==1&&T::releases==0);
 resize(&camera,&mat,2);assert(camera.target!=first&&camera.target->width==2160&&T::allocations==2&&T::releases==1&&T::destroys==1&&mat.tex==camera.target);
 resize(&camera,&mat,2.00001f);assert(T::allocations==2); // same integer pixel resolution
 std::cout<<"Actual mirror resize: 100 Size updates reuse the target; dimension change reallocates once, rebinds then releases/destroys old target. Unity GPU not simulated.\n";
}
'''
with tempfile.TemporaryDirectory() as td:
 td=Path(td);(td/'test.cpp').write_text(code)
 subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(td/'test.cpp'),'-o',str(td/'test')],check=True)
 subprocess.run([str(td/'test')],check=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
