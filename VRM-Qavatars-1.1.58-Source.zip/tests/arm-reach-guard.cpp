#include "customTypes/FinalIK/VR/ArmReachGuard.hpp"
#include <cstdlib>
#include <iostream>
#include <limits>
using VRMQavatars::FinalIK::ArmReachGuard;
int checks=0;
void check(bool b, const char* name) { if (!b) { std::cerr << "FAIL " << name << '\n'; std::exit(1); } ++checks; std::cout << "PASS " << name << '\n'; }
bool near(float a,float b) { return std::abs(a-b)<0.00001f; }
int main() {
 ArmReachGuard left,right;
 check(near(left.Update(1.0f,1.f/72),1.f) && !left.detached,"ordinary reach tracks normally");
 check(near(left.Update(1.29f,1.f/72),1.f),"limited extra reach remains tracked");
 check(near(left.Update(1.30f,1.f/72),1.f),"exact outward boundary remains tracked");
 float w=left.Update(1.31f,1.f/72); check(left.detached && w>0.f && w<1.f,"excess reach starts a smooth release");
 for(int i=0;i<30;i++)left.Update(1.8f,1.f/72);
 check(near(left.trackingWeight,0.f),"persistent excess reach reaches neutral pose weight");
 left.Update(1.29f,1.f/72);check(left.detached,"outer band does not reconnect");
 for(int i=0;i<100;i++)left.Update(i%2?1.29f:1.31f,1.f/72);
 check(left.detached && near(left.trackingWeight,0.f),"boundary jitter does not repeatedly attach/detach");
 left.Update(1.25f,1.f/72);check(!left.detached && left.trackingWeight>0 && left.trackingWeight<1,"inner boundary begins smooth reconnect");
 for(int i=0;i<30;i++)left.Update(1.f,1.f/72);
 check(near(left.trackingWeight,1.f),"full reconnection within reach");
 check(!right.detached && near(right.trackingWeight,1.f),"other hand remains independent");
 left.Update(std::numeric_limits<float>::quiet_NaN(),.01f);check(left.detached,"invalid tracking value releases the hand");
 left.Reset();check(!left.detached && near(left.trackingWeight,1.f),"recalibration resets state");
 check(near(left.Update(3.f,0.f),1.f) && left.detached,"zero dt changes state without a jump");
 check(near(left.Update(3.f,std::numeric_limits<float>::quiet_NaN()),1.f),"invalid dt cannot poison blend");
 check(near(left.Update(3.f,-1.f),1.f),"negative dt ignored");
 check(near(ArmReachGuard::StretchMultiplier(3.f,1.f),1.3f),"hard upper bound replaces double length");
 check(near(ArmReachGuard::StretchMultiplier(1.1f,1.f),1.1f),"allowed extension preserved");
 check(near(ArmReachGuard::StretchMultiplier(.4f,1.f),1.f),"stretch never shrinks below natural length");
 check(near(ArmReachGuard::StretchMultiplier(3.f,.5f),1.15f),"partial IK weight bounded");
 check(near(ArmReachGuard::StretchMultiplier(3.f,0.f),1.f),"zero IK weight preserves natural length");
 for(float length : {.12f,.6f,1.5f}) { ArmReachGuard a; a.Update(length*1.31f/length,.02f);check(a.detached,"threshold scales with calibrated avatar size"); }
 for(int fps : {36,72,90,120}) { ArmReachGuard a;for(int i=0;i<fps/2;i++)a.Update(2.f,1.f/fps);check(near(a.trackingWeight,0.f),"neutral reached at different frame rates");for(int i=0;i<fps/2;i++)a.Update(1.f,1.f/fps);check(near(a.trackingWeight,1.f),"tracking restored at different frame rates"); }
 std::cout<<"All "<<checks<<" reach guard checks passed; Quest runtime not tested.\n";
}
