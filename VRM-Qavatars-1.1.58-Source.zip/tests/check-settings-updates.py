#!/usr/bin/env python3
"""Actual ConfigValue and AvatarManager::UpdateVRIK with host spies.
Checks persistence coalescing and absence of per-slider extra IK solves.
"""
from pathlib import Path
import os,subprocess,tempfile
r=Path(__file__).resolve().parents[1]
def body(path,sig):
 t=path.read_text();a=t.index(sig);b=t.index('{',a)+1;d=1
 while d:d+=(t[b]=='{')-(t[b]=='}');b+=1
 return t[a:b]
current=body(r/'src/AvatarManager.cpp','void AvatarManager::UpdateVRIK()')
fixture=r/'tests/fixtures/beta52-UpdateVRIK.cpp'
old=fixture.read_text()
mini=(r/'include/config/mini-config-utils.hpp').read_text();a=mini.index('namespace ConfigUtils {');b=mini.index('#pragma region CodegenValues',a);configvalue=mini[a:b].replace('    static constexpr auto Logger = Paper::ConstLoggerContext("config-utils");','')
configtest=r'''
#include <cassert>
#include <functional>
#include <mutex>
#include <vector>
#include <iostream>
#include "config/ConfigWriteQueue.hpp"
'''+configvalue+r'''
using Q=VRMQavatars::Config::ConfigWriteQueue;int writesA=0,writesB=0;
void saveA(){++writesA;}void saveB(){++writesB;}
int main(){int memory=0,events=0;ConfigUtils::ConfigValue<int> value(&saveA,&memory,"test",0);
 value.AddChangeEvent([&](int v){assert(memory==v);++events;});
 value.SetValue(7);assert(writesA==1&&events==1&&memory==7);
 Q::Begin();for(int i=0;i<100;++i)value.SetValue(i);Q::Request(&saveB);
 assert(memory==99&&events==101&&writesA==1&&writesB==0);
 Q::Tick(std::chrono::steady_clock::now()+std::chrono::milliseconds(200));assert(writesA==1&&writesB==0);
 Q::Tick(std::chrono::steady_clock::now()+std::chrono::milliseconds(300));assert(writesA==2&&writesB==1);
 Q::Tick(std::chrono::steady_clock::now()+std::chrono::seconds(1));assert(writesA==2);
 value.SetValue(100);Q::Flush();assert(writesA==3); // config switches must flush before resetting data
 Q::Request(&saveB);Q::End();assert(writesB==2);
 value.SetValue(101);assert(writesA==4);
 value.SetValue(102,false);assert(writesA==4&&events==104&&memory==102);
 std::cout<<"Actual ConfigValue: immediate values/events, 100 edits coalesced, 250ms idle save, flush/end and non-save paths passed.\n";
}
'''
stubs=r'''
#include <array>
#include <algorithm>
#include <cassert>
#include <iostream>
#include <string>
namespace VRMQavatars {
struct Part {float bodyPosStiffness,headClampWeight,maintainPelvisPosition,minHeadHeight,maxRootAngle,swivelOffset,shoulderRotationWeight,pelvisRotationWeight,pelvisPositionWeight,chestGoalWeight,positionWeight,bendGoalWeight;void *pelvisTarget,*chestGoal,*target,*bendGoal;};
struct Locomotion {float footDistance,stepThreshold,angleThreshold,maxVelocity,velocityFactor,rootSpeed,stepSpeed;int offset;};
struct Solver {bool initiated=true;Part sp,la,ra,ll,rl;Locomotion lo;Part *spine=&sp,*leftArm=&la,*rightArm=&ra,*leftLeg=&ll,*rightLeg=&rl;Locomotion* locomotion=&lo;std::array<Part*,2>legs{&ll,&rl};};
struct VRIK {Solver* solver;int solves=0;void UpdateSolverExternal(){++solves;}};
struct Target {void* get_transform(){return this;}};
struct Targets {Target a;Target *waistTracker=&a,*chestTracker=&a,*leftFootTracker=&a,*rightFootTracker=&a,*leftKneeTracker=&a,*rightKneeTracker=&a;};
namespace Config {struct ConfigManager {
 struct IK {float bodyStiffness=.75,armSwivel=0,legSwivel=0,shoulderRotationWeight=.4;};
 struct Loco {float footDistance=.1,stepThreshold=.1;int stepOffset=0;};
 struct VMC {std::string waistTracker="None",chestTracker="None",leftFoot="None",rightFoot="None",leftKnee="None",rightKnee="None";bool enableFBT=false;};
 static inline float bodyValue=.75f;static IK GetIKSettings(){IK s{};s.bodyStiffness=bodyValue;return s;};static Loco GetLocomotionSettings(){return {};};static VMC GetVMCSettings(){return {};};
};}
struct AvatarManager {static inline VRIK* vrik=nullptr;static inline Targets* targetManager=nullptr;static void UpdateVRIK();};
'''
main=r'''
}
int main(){using namespace VRMQavatars;Solver solver;VRIK vrik{&solver};Targets targets;AvatarManager::vrik=&vrik;AvatarManager::targetManager=&targets;
 for(int i=0;i<100;++i)AvatarManager::UpdateVRIK();assert(vrik.solves==0);
 assert(solver.leftArm->shoulderRotationWeight==.4f&&solver.rightArm->shoulderRotationWeight==.4f);
 Config::ConfigManager::bodyValue=5;AvatarManager::UpdateVRIK();assert(solver.spine->bodyPosStiffness==1);
 Config::ConfigManager::bodyValue=-2;AvatarManager::UpdateVRIK();assert(solver.spine->bodyPosStiffness==0);
 solver.initiated=false;AvatarManager::UpdateVRIK();AvatarManager::vrik=nullptr;AvatarManager::UpdateVRIK();
 std::cout<<"Actual UpdateVRIK: 100 settings applications without out-of-frame solves; both shoulder weights applied; null/uninitiated guards passed.\n";
}
'''
with tempfile.TemporaryDirectory() as td:
 td=Path(td)
 for name,code in [('persistence',configtest),('settings',stubs+current+main),('old-settings',stubs+old+main)]:
  p=td/(name+'.cpp');p.write_text(code);exe=td/name
  subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(r/'include'),str(p),'-o',str(exe)],check=True)
  x=subprocess.run([str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
  if name=='old-settings':assert x.returncode!=0;print('Negative control: original per-slider extra solve fails, as expected.')
  else:print(x.stdout);print(x.stderr);assert x.returncode==0
ui=(r/'src/UI/AvatarSettingsViewController.cpp').read_text()
assert 'ResetIKSettings();\n                                UpdateIKTab();' in ui
assert 'ConfigWriteQueue::Begin();' in ui and 'ConfigWriteQueue::End();' in ui
assert 'beatmapLightingColorIntensitySlider->SetValue(Config::ConfigManager::GetLightingSettings().beatmapLightingColorIntensity)' in ui
for path in ['src/AvatarManager.cpp','src/SceneEventManager.cpp','src/config/ConfigManager.cpp']:assert 'ConfigWriteQueue::Flush();' in (r/path).read_text()
print('UI lifecycle, config-switch flush and corrected settings refresh checks passed; Quest runtime not simulated.')
