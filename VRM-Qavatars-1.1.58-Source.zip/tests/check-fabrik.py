#!/usr/bin/env python3
"""Exercise actual FABRIK bodies with host vectors; no Unity/rotation simulation.

Only vector property syntax is adapted for g++; SwingRotation is a no-op here.
A legacy-loop negative control must fail the reachable-target regression.
"""
from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root/'src/customTypes/FinalIK/VR/VirtualBone.cpp').read_text()
def extract(signature):
    start=source.index(signature); end=source.index('{',start)+1; depth=1; i=end
    while depth:
        depth+=(source[i]=='{')-(source[i]=='}'); i+=1
    return source[start:i].replace('.magnitude','.magnitude()').replace('.normalized','.normalized()')
body=extract('void VirtualBone::SolveFABRIK(')+'\n'+extract('Sombrero::FastVector3 VirtualBone::SolveFABRIKJoint(')
stubs=r'''
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>
namespace Sombrero {
struct FastVector3 {
 float x=0,y=0,z=0;
 FastVector3 operator+(FastVector3 b)const{return {x+b.x,y+b.y,z+b.z};}
 FastVector3 operator-(FastVector3 b)const{return {x-b.x,y-b.y,z-b.z};}
 FastVector3 operator*(float s)const{return {x*s,y*s,z*s};}
 FastVector3 operator/(float s)const{return {x/s,y/s,z/s};}
 FastVector3& operator+=(FastVector3 b){*this=*this+b;return *this;}
 float magnitude()const{return std::sqrt(x*x+y*y+z*z);}
 FastVector3 normalized()const{float m=magnitude();return m>1e-8f?*this/m:FastVector3{};}
 static FastVector3 Lerp(FastVector3 a,FastVector3 b,float t){return a+(b-a)*std::clamp(t,0.f,1.f);}
};}
using V=Sombrero::FastVector3;
struct VirtualBone {
 V solverPosition;float length;
 static void SwingRotation(std::vector<VirtualBone*>,int,V,float){}
 static void SolveFABRIK(std::vector<VirtualBone*>,V,V,float,float,int,float,V);
 static V SolveFABRIKJoint(V,V,float);
};
'''
main=r'''
bool finite(V a){return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z);}
int main(){
 for(V target:std::vector<V>{{1.f,1.5f,0},{-.6f,.9f,.3f},{.15f,.45f,.1f}}){
  VirtualBone a{{0,0,0},1},b{{0,1,0},1},c{{0,2,0},0};std::vector<VirtualBone*> chain{&a,&b,&c};
  VirtualBone::SolveFABRIK(chain,{0,0,0},target,1,0,128,2,{});
  if((a.solverPosition-V{}).magnitude()>1e-6f || (c.solverPosition-target).magnitude()>1e-3f)return 42;
  if(std::abs((b.solverPosition-a.solverPosition).magnitude()-1)>1e-5f || std::abs((c.solverPosition-b.solverPosition).magnitude()-1)>1e-5f)return 43;
 }
 // Zero distance and too-short chains must not underflow or create NaNs.
 VirtualBone a{{0,0,0},1},b{{0,1,0},1},c{{0,2,0},0};
 VirtualBone::SolveFABRIK({&a,&b,&c},{},{},1,1,2,2,{});
 if(!finite(a.solverPosition)||!finite(b.solverPosition)||!finite(c.solverPosition))return 44;
 VirtualBone::SolveFABRIK({}, {}, {},1,1,1,1,{});
 VirtualBone::SolveFABRIK({&a}, {}, {},1,1,1,1,{});
 V old=b.solverPosition;VirtualBone::SolveFABRIK({&a,&b}, {}, {5,5,5},0,0,1,1,{});
 if((b.solverPosition-old).magnitude()>1e-6f)return 45;
 std::cout<<"FABRIK: reachable targets, crouch-like targets, lengths, root anchor, coincident target, empty/single chain and zero weight passed.\n";
}
'''
with tempfile.TemporaryDirectory() as temporary:
    directory=Path(temporary)
    for label,code in [('fixed',body),('legacy-loop',body.replace('int j = static_cast<int>(bones.size()) - 2; j >= 0; --j','size_t j = bones.size() - 2; j > -1; j--'))]:
        cpp=directory/(label+'.cpp'); binary=directory/label;cpp.write_text(stubs+code+main)
        subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(cpp),'-o',str(binary)],check=True)
        result=subprocess.run([str(binary)],env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
        if label=='fixed':assert result.returncode==0,result.returncode
        else:assert result.returncode==42,result.returncode
    print('Negative control: original unsigned backward loop fails reachable-target test (exit 42), as expected.')
