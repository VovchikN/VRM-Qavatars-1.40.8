void AvatarManager::UpdateVRIK()
    {
        if(vrik == nullptr || !vrik->solver->initiated) return;
        auto ikSettings = Config::ConfigManager::GetIKSettings();
        auto locoSettings = Config::ConfigManager::GetLocomotionSettings();

        //vrik->fixTransforms = true;
        vrik->solver->spine->bodyPosStiffness = ikSettings.bodyStiffness;
        vrik->solver->spine->headClampWeight = 0.38f;
        vrik->solver->spine->maintainPelvisPosition = 0.0f;
        vrik->solver->spine->minHeadHeight = -10.0f;

        vrik->solver->spine->maxRootAngle = 0.0f;

        vrik->solver->leftArm->swivelOffset = ikSettings.armSwivel;
        vrik->solver->rightArm->swivelOffset = ikSettings.armSwivel * -1.0f;
        vrik->solver->leftLeg->swivelOffset = ikSettings.legSwivel;
        vrik->solver->rightLeg->swivelOffset = ikSettings.legSwivel * -1.0f;

        vrik->solver->locomotion->footDistance = locoSettings.footDistance;
        vrik->solver->locomotion->stepThreshold = locoSettings.stepThreshold;
        vrik->solver->locomotion->angleThreshold = 45.0f;
        vrik->solver->locomotion->maxVelocity = 0.04f;
        vrik->solver->locomotion->velocityFactor = 0.04f;
        vrik->solver->locomotion->rootSpeed = 40.0f;
        vrik->solver->locomotion->stepSpeed = 2.0f;

        vrik->solver->locomotion->offset = locoSettings.stepOffset;

        const auto vmcSettings = Config::ConfigManager::GetVMCSettings();

        const bool pelvis = vmcSettings.waistTracker != "None" && vmcSettings.enableFBT;
        vrik->solver->spine->pelvisTarget = pelvis ? targetManager->waistTracker->get_transform() : nullptr;
        vrik->solver->spine->pelvisRotationWeight = pelvis ? 1.0f : 0.0f;
        vrik->solver->spine->pelvisPositionWeight = pelvis ? 1.0f : 0.0f;

        const bool chest = vmcSettings.chestTracker != "None" && vmcSettings.enableFBT;
        vrik->solver->spine->chestGoal = chest ? targetManager->chestTracker->get_transform() : nullptr;
        vrik->solver->spine->chestGoalWeight = chest ? 1.0f : 0.0f;

        const bool lFoot = vmcSettings.leftFoot != "None" && vmcSettings.enableFBT;
        vrik->solver->legs[0]->target = lFoot ? targetManager->leftFootTracker->get_transform() : nullptr;
        vrik->solver->legs[0]->positionWeight = lFoot ? 1.0f : 0.0f;

        const bool rFoot = vmcSettings.rightFoot != "None" && vmcSettings.enableFBT;
        vrik->solver->legs[1]->target = rFoot ? targetManager->rightFootTracker->get_transform() : nullptr;
        vrik->solver->legs[1]->positionWeight = rFoot ? 1.0f : 0.0f;

        const bool lKnee = vmcSettings.leftKnee != "None" && vmcSettings.enableFBT;
        vrik->solver->legs[0]->bendGoal = lKnee ? targetManager->leftKneeTracker->get_transform() : nullptr;
        vrik->solver->legs[0]->bendGoalWeight = lKnee ? 1.0f : 0.0f;

        const bool rKnee = vmcSettings.rightKnee != "None" && vmcSettings.enableFBT;
        vrik->solver->legs[1]->bendGoal = rKnee ? targetManager->rightKneeTracker->get_transform() : nullptr;
        vrik->solver->legs[1]->bendGoalWeight = rKnee ? 1.0f : 0.0f;

        vrik->UpdateSolverExternal();
    }
