Unmodified source files extracted from the delivered beta.5 full archive (SHA256 e6f7c33f78e9be7fb0469a214448ca716417bb24ea21a71f06b62257e5d71591), retained only as the load-order regression control.
