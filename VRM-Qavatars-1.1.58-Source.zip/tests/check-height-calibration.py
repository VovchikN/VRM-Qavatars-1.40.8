#!/usr/bin/env python3
"""Run the actual calibration coroutine/commit/prepare methods with host stubs.

Checks whole-root hierarchy scaling, selected modes, repeat/restore/cancel paths.
No Unity Animator, skinned-mesh GPU, IL2CPP or real tracking is executed.
"""
from pathlib import Path
import os,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
cpp=(root/'src/CalibrationHelper.cpp').read_text()
cpp='\n'.join(l for l in cpp.splitlines() if not l.startswith('#include'))
stubs=r'''
#include <algorithm>
#include <cassert>
#include <cmath>
#include <coroutine>
#include <exception>
#include <iostream>
#include <limits>
#include <optional>
#include <string>
#include <utility>
#include <vector>
#include "utils/CalibrationMath.hpp"
namespace custom_types::Helpers {
struct Coroutine {
 struct promise_type {
  Coroutine get_return_object(){return {std::coroutine_handle<promise_type>::from_promise(*this)};}
  std::suspend_never initial_suspend(){return {};}
  std::suspend_always final_suspend()noexcept{return {};}
  std::suspend_always yield_value(void*){return {};}
  void return_void(){}void unhandled_exception(){std::rethrow_exception(std::current_exception());}
 };
 std::coroutine_handle<promise_type> h;
 Coroutine(std::coroutine_handle<promise_type> v):h(v){}
 Coroutine(Coroutine&& o):h(std::exchange(o.h,{})){}
 ~Coroutine(){if(h)h.destroy();}
 void finish(){int i=0;while(!h.done()){assert(++i<100);h.resume();}}
};}
namespace System::Collections {struct IEnumerator{};}
namespace CP_SDK::UI::Components {struct CText {void SetText(const std::u16string&){};};}
template<class T>using SafePtrUnity=T*;
namespace fmt {template<class...A>std::string format(const char* f,A...){return f;}}
struct Logger {template<class...A>void info(const char*,A...){}template<class...A>void error(const char*,A...) {}} VRMLogger;
namespace UnityEngine {
 struct Vector3 {float x=0,y=0,z=0;Vector3()=default;Vector3(float a,float b,float c):x(a),y(b),z(c){};
 Vector3 operator-(Vector3 b)const{return {x-b.x,y-b.y,z-b.z};}
 static float Distance(Vector3 a,Vector3 b){auto d=a-b;return std::sqrt(d.x*d.x+d.y*d.y+d.z*d.z);}
 static Vector3 forward(){return {0,0,1};}
 };
 struct Quaternion {static Quaternion Euler(float,float,float){return {};};Vector3 get_eulerAngles(){return {};};static Quaternion LookRotation(Vector3,Vector3){return {};}};
 enum class HumanBodyBones {Hips,LeftUpperArm,RightUpperArm,LeftUpperLeg,RightUpperLeg,Head,RightHand,LeftHand};
 struct Transform {
  Transform* parent=nullptr;Vector3 localPosition{},localScale{1,1,1};void* component=nullptr;
  Vector3 get_localPosition(){return localPosition;}void set_localPosition(Vector3 v){localPosition=v;}
  Vector3 get_localScale(){return localScale;}void set_localScale(Vector3 v){localScale=v;}
  Vector3 get_lossyScale(){auto p=parent?parent->get_lossyScale():Vector3{1,1,1};return {p.x*localScale.x,p.y*localScale.y,p.z*localScale.z};}
  Vector3 get_position(){if(!parent)return localPosition;auto p=parent->get_position(),s=parent->get_lossyScale();return {p.x+s.x*localPosition.x,p.y+s.y*localPosition.y,p.z+s.z*localPosition.z};}
  void set_position(Vector3 v){assert(!parent);localPosition=v;}void set_eulerAngles(Vector3){}void set_rotation(Quaternion){}
  template<class T>T GetComponent(){return static_cast<T>(component);}
  template<class T>std::vector<T> GetComponentsInChildren(){return {};}
 };
 struct GameObject {Transform* trans;Transform* get_transform(){return trans;}};
 struct Animator {Transform* bones[8];Transform* GetBoneTransform(HumanBodyBones b){return bones[static_cast<int>(b)];}};
 struct Time {static float get_deltaTime(){return 1.f;}};
 struct WaitForEndOfFrame {static void* New_ctor(){static int value;return &value;}};
}
namespace Sombrero {using FastVector3=UnityEngine::Vector3;using FastQuaternion=UnityEngine::Quaternion;}
namespace GlobalNamespace {struct OVRPlugin {
 enum class Node {Head,HandLeft,HandRight};enum class Step {Render};
 struct V {float x=0,y=0,z=0;};struct Pose{V Position;};
 static inline float height=1.8f,span=1.4f;
 static Pose GetNodePose(Node n,Step){return {{n==Node::HandLeft?-span/2:n==Node::HandRight?span/2:0,n==Node::Head?height:1.f,0}};}
};}
#define CRASH_UNLESS(x) (x)
namespace VRMQavatars {
namespace Config {
 template<class T>struct Value {T v;T GetValue(){return v;}void SetValue(T x){v=x;}};
 struct Global {Value<int>CalibrationType{2};Value<float>FixedScale{1};Value<bool>UncannyLongArmsFunnyUnderscoresReference{false};};
 struct Avatar {Value<float>ArmCalibrationScale{1},LegCalibrationScale{1},CalibratedScale{1};Value<bool>HasCalibrated{false};};
 struct Finger{std::string grabPose;};
 struct ConfigManager {
 static inline Global g;static inline Avatar a;static inline int saves=0;
 static Global& GetGlobalConfig(){return g;}static Avatar& GetAvatarConfig(){return a;}
 static Finger GetFingerPoseSettings(){return {};}
 static void SaveAvatarConfig(){++saves;}
 };
}
struct VRMSpringBone {void set_enabled(bool){}};
namespace FinalIK {
 struct Part {UnityEngine::Transform* target=nullptr;UnityEngine::Transform* headTarget=nullptr;};
 struct Solver {Part parts[3];Part *spine=&parts[0],*leftArm=&parts[1],*rightArm=&parts[2];int resets=0;void FixTransforms(){}void Reset(){++resets;}};
 struct VRIK {
 UnityEngine::Animator* animator;Solver* solver;UnityEngine::Transform* root;
 bool calibrating=false,componentInitiated=true,skipSolverUpdate=false,updateFrame=false;
 float initializedScale=0;int inits=0;void set_enabled(bool){}
 void Initiate(){assert(!calibrating);initializedScale=root->get_localScale().y;componentInitiated=true;++inits;}
 };
}
struct TargetManager {bool intialized=false;UnityEngine::GameObject* headTarget;UnityEngine::GameObject* leftHandTarget;UnityEngine::GameObject* rightHandTarget;int updates=0;void Update(){assert(intialized);++updates;}};
struct Context {UnityEngine::GameObject* rootGameObject;};
struct AvatarManager {
 static inline Context* currentContext=nullptr;static inline FinalIK::VRIK* vrik=nullptr;static inline TargetManager* targetManager=nullptr;
 static void UpdateVRIK(){assert(vrik->initializedScale==currentContext->rootGameObject->get_transform()->get_localScale().y);}
};
struct TPoseHelper {static inline std::vector<UnityEngine::Transform*> transforms;static inline std::vector<UnityEngine::Vector3> positions;
 static void Save(){positions.clear();for(auto* t:transforms)positions.push_back(t->get_localPosition());}
 static void LoadPose(){for(int i=0;i<transforms.size();++i){transforms[i]->set_localPosition(positions[i]);transforms[i]->set_localScale({1,1,1});}}
};
struct HandController{static void ApplyHandPose(UnityEngine::Animator*,const std::string&){}};
struct CalibrationHelper {
 static void BindStatusLabel(CP_SDK::UI::Components::CText*);static void PrepareContextForCalibration();
 static Sombrero::FastVector3 GetPosition(GlobalNamespace::OVRPlugin::Node);
 static void Calibrate(std::optional<float>);
 static custom_types::Helpers::Coroutine StartCalibrationProc(bool fitHeight=false);
};
}
'''
main=r'''
int main(){using namespace VRMQavatars;using namespace UnityEngine;using CM=Config::ConfigManager;
 Transform root,b[8],targets[3];root.localPosition={0,0,0};
 // Hierarchical rest pose: hips -> head/arms; root -> legs. No solver stretch.
 for(auto& t:b)t.parent=&root;
 b[0].localPosition={0,.75f,0};b[5].parent=&b[0];b[5].localPosition={0,.5f,0};
 b[1].localPosition={-.2f,1,0};b[2].localPosition={.2f,1,0};
 b[3].localPosition={-.1f,.6f,0};b[4].localPosition={.1f,.6f,0};
 b[6].localPosition={.5f,1,0};b[7].localPosition={-.5f,1,0};
 Animator animator;for(int i=0;i<8;++i)animator.bones[i]=&b[i];
 FinalIK::Solver solver;FinalIK::VRIK vrik{&animator,&solver,&root};root.component=&vrik;
 GameObject object{&root},tg[3]{{&targets[0]},{&targets[1]},{&targets[2]}};Context ctx{&object};TargetManager tm{false,&tg[0],&tg[1],&tg[2]};
 AvatarManager::currentContext=&ctx;AvatarManager::vrik=&vrik;AvatarManager::targetManager=&tm;
 TPoseHelper::transforms={&root};for(auto& t:b)TPoseHelper::transforms.push_back(&t);TPoseHelper::Save();
 const auto near=[](float a,float b){assert(std::abs(a-b)<1e-4f);};
 for(int selected:{0,1,2})for(float head:{1.50f,1.80f,1.95f}){
  CM::g.CalibrationType.v=selected;GlobalNamespace::OVRPlugin::height=head;
  auto c=CalibrationHelper::StartCalibrationProc(true);c.finish();float expected=head/1.25f;
  near(root.localScale.x,expected);near(root.localScale.y,expected);near(root.localScale.z,expected);
  near(b[0].get_position().y,.75f*expected);near(b[5].get_position().y,head);
  near(Vector3::Distance(b[1].get_position(),b[2].get_position()),.4f*expected);
  near(b[3].get_position().y,.6f*expected);near(vrik.initializedScale,expected);
  near(CM::a.CalibratedScale.v,expected);assert(CM::a.HasCalibrated.v&&CM::g.CalibrationType.v==selected);
  // No per-arm scaling was used to satisfy this size test.
  near(b[1].localScale.x,1.f);near(b[2].localScale.x,1.f);
  // Repeated calibration and loading a saved scale must not compound the scale.
  auto repeat=CalibrationHelper::StartCalibrationProc(true);repeat.finish();near(root.localScale.y,expected);
  CalibrationHelper::Calibrate(CM::a.CalibratedScale.v);near(root.localScale.y,expected);near(b[5].get_position().y,head);
  std::cout<<"selected="<<selected<<" Fit Height: head="<<head<<" root="<<expected<<" torso/width/legs scaled; repeated/restore pass\n";
 }
 // The legacy selected-mode path still honors Fixed/Armspan, deliberately.
 CM::g.CalibrationType.v=2;CM::g.FixedScale.v=1;GlobalNamespace::OVRPlugin::height=1.8;
 auto fixed=CalibrationHelper::StartCalibrationProc();fixed.finish();near(root.localScale.y,1);
 near(b[5].get_position().y,1.25f); // Matches the reported small body IF Fixed was selected.
 CM::g.CalibrationType.v=0;auto armspan=CalibrationHelper::StartCalibrationProc();armspan.finish();near(root.localScale.y,1.4f);
 CM::g.CalibrationType.v=1;auto height=CalibrationHelper::StartCalibrationProc();height.finish();near(root.localScale.y,1.44f);
 float saved=CM::a.CalibratedScale.v;GlobalNamespace::OVRPlugin::height=0;
 auto bad=CalibrationHelper::StartCalibrationProc(true);bad.finish();near(root.localScale.y,saved);
 GlobalNamespace::OVRPlugin::height=std::numeric_limits<float>::quiet_NaN();auto nan=CalibrationHelper::StartCalibrationProc(true);nan.finish();near(root.localScale.y,saved);
 GlobalNamespace::OVRPlugin::height=1.8;auto cancelled=CalibrationHelper::StartCalibrationProc(true);
 AvatarManager::currentContext=nullptr;int commits=CM::saves;cancelled.finish();assert(CM::saves==commits);
 AvatarManager::vrik=nullptr;auto empty=CalibrationHelper::StartCalibrationProc(true);empty.finish();
 std::cout<<"Actual prepare/preview/commit coroutine, 3 saved modes x 3 heights, full hierarchy, persistence, invalid tracking and context cancellation passed. Unity runtime not simulated.\n";
}
'''
with tempfile.TemporaryDirectory() as td:
 p=Path(td);(p/'test.cpp').write_text(stubs+cpp+main)
 subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(root/'include'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True,env={**os.environ,"ASAN_OPTIONS":"detect_leaks=0"})
# The optional height action stays explicit; the primary action follows the selected mode.
ui=(root/'src/UI/AvatarSelectionViewController.cpp').read_text()
assert 'XUISecondaryButton::Make(u"Fit Height (optional)")\n                    ->OnClick({this, &AvatarSelectionViewController::FitHeight})' in ui
assert 'CoroutineHelper::New(CalibrationHelper::StartCalibrationProc(true))' in ui
assert 'XUIPrimaryButton::Make(u"Recalibrate")\n                        ->OnClick({this, &AvatarSelectionViewController::Calibrate})' in ui
print('Selected-mode primary action and optional Fit Height wiring checked.')
