#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>
#include <iostream>
#include <cassert>
namespace Sombrero {
struct FastVector3 {
 float x=0,y=0,z=0;FastVector3()=default;FastVector3(float X,float Y,float Z):x(X),y(Y),z(Z){}
 static FastVector3 zero(){return {};};static FastVector3 up(){return {0,1,0};};static FastVector3 down(){return {0,-1,0};};static FastVector3 right(){return {1,0,0};};static FastVector3 left(){return {-1,0,0};};static FastVector3 forward(){return {0,0,1};};static FastVector3 back(){return {0,0,-1};}
 FastVector3 operator+(FastVector3 b)const{return{x+b.x,y+b.y,z+b.z};} FastVector3 operator-(FastVector3 b)const{return{x-b.x,y-b.y,z-b.z};} FastVector3 operator-()const{return{-x,-y,-z};}FastVector3 operator*(float s)const{return{x*s,y*s,z*s};}FastVector3 operator/(float s)const{return{x/s,y/s,z/s};}
 FastVector3& operator+=(FastVector3 b){return *this=*this+b;}FastVector3& operator-=(FastVector3 b){return *this=*this-b;}FastVector3& operator*=(float s){return *this=*this*s;}
 bool operator==(FastVector3 b)const{return (*this-b).sqrMagnitude()<1e-12;} bool Equals(FastVector3 b)const{return *this==b;}
 float sqrMagnitude()const{return x*x+y*y+z*z;}float get_magnitude()const{return std::sqrt(sqrMagnitude());}float get_normalized_dummy()const{return 0;}
 __declspec(property(get=get_magnitude)) float magnitude;
 FastVector3 get_normalized()const{float m=get_magnitude();return m<1e-6?zero():*this/m;}__declspec(property(get=get_normalized)) FastVector3 normalized;
 float Distance(FastVector3 b)const{return (*this-b).get_magnitude();}
 static float Dot(FastVector3 a,FastVector3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
 static FastVector3 Cross(FastVector3 a,FastVector3 b){return{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
 static FastVector3 Lerp(FastVector3 a,FastVector3 b,float t){return a+(b-a)*std::clamp(t,0.f,1.f);}
 static FastVector3 Slerp(FastVector3 a,FastVector3 b,float t){return Lerp(a,b,t);}
 static FastVector3 Project(FastVector3 a,FastVector3 n){float d=Dot(n,n);return d<1e-12?zero():n*(Dot(a,n)/d);}
 static void OrthoNormalize(FastVector3& n,FastVector3& t){n=n.normalized;t=(t-Project(t,n)).normalized;}
};
struct FastQuaternion {
 float x=0,y=0,z=0,w=1;FastQuaternion()=default;FastQuaternion(float X,float Y,float Z,float W):x(X),y(Y),z(Z),w(W){}
 static FastQuaternion identity(){return {};}
 static float Dot(FastQuaternion a,FastQuaternion b){return a.x*b.x+a.y*b.y+a.z*b.z+a.w*b.w;}
 static FastQuaternion Normalize(FastQuaternion q){float d=std::sqrt(Dot(q,q));return d<1e-8?identity():FastQuaternion(q.x/d,q.y/d,q.z/d,q.w/d);}
 static FastQuaternion Inverse(FastQuaternion q){float d=Dot(q,q);return{-q.x/d,-q.y/d,-q.z/d,q.w/d};}
 FastQuaternion operator*(FastQuaternion b)const{return{w*b.x+x*b.w+y*b.z-z*b.y,w*b.y-x*b.z+y*b.w+z*b.x,w*b.z+x*b.y-y*b.x+z*b.w,w*b.w-x*b.x-y*b.y-z*b.z};}
 FastVector3 operator*(FastVector3 p)const{auto t=FastVector3::Cross({x,y,z},p)*2;return p+t*w+FastVector3::Cross({x,y,z},t);}
 bool operator==(FastQuaternion b)const{return x==b.x&&y==b.y&&z==b.z&&w==b.w;}
 static FastQuaternion Lerp(FastQuaternion a,FastQuaternion b,float t){float s=Dot(a,b)<0?-1:1;t=std::clamp(t,0.f,1.f);return Normalize({a.x*(1-t)+b.x*t*s,a.y*(1-t)+b.y*t*s,a.z*(1-t)+b.z*t*s,a.w*(1-t)+b.w*t*s});}
 static FastQuaternion Slerp(FastQuaternion a,FastQuaternion b,float t){
  a=Normalize(a);b=Normalize(b);float dot=Dot(a,b);if(dot<0){b={-b.x,-b.y,-b.z,-b.w};dot=-dot;}
  if(dot>.9995f)return Lerp(a,b,t);float angle=std::acos(std::clamp(dot,-1.f,1.f));float den=std::sin(angle);
  float u=std::sin((1-t)*angle)/den,v=std::sin(t*angle)/den;return Normalize({a.x*u+b.x*v,a.y*u+b.y*v,a.z*u+b.z*v,a.w*u+b.w*v});
 }
 static float Angle(FastQuaternion a,FastQuaternion b){return std::acos(std::min(1.f,std::abs(Dot(Normalize(a),Normalize(b)))))*114.59156f;}
 static FastQuaternion AngleAxis(float deg,FastVector3 a){a=a.normalized;float r=deg*.00872664626f,s=std::sin(r);return{a.x*s,a.y*s,a.z*s,std::cos(r)};}
 static FastQuaternion FromToRotation(FastVector3 a,FastVector3 b){a=a.normalized;b=b.normalized;float d=FastVector3::Dot(a,b);if(a.get_magnitude()<1e-5||b.get_magnitude()<1e-5)return {};if(d<-.9999f){auto c=FastVector3::Cross(a,FastVector3::right());if(c.get_magnitude()<1e-5)c=FastVector3::Cross(a,FastVector3::up());return AngleAxis(180,c);}auto c=FastVector3::Cross(a,b);return Normalize({c.x,c.y,c.z,1+d});}
 static FastQuaternion LookRotation(FastVector3 forward,FastVector3 up){auto q=FromToRotation(FastVector3::forward(),forward);auto right=FastVector3::Cross(up,forward).normalized;auto desiredUp=FastVector3::Cross(forward.normalized,right);return FromToRotation(q*FastVector3::up(),desiredUp)*q;}
};
}
namespace UnityEngine {using Vector3=Sombrero::FastVector3;using Quaternion=Sombrero::FastQuaternion;struct Transform{Vector3 position;Quaternion rotation;};}
#define byref(x) x
