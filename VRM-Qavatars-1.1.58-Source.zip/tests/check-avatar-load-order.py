#!/usr/bin/env python3
"""Actual initialization/finger-pose method bodies with Unity/solver stubs.

The original beta.5 path reproduces the missing Animator before finger setup.
This is a lifecycle regression test; it does not run IL2CPP or GPU code.
"""
from pathlib import Path
import argparse,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--baseline-source',type=Path,default=root/'tests/fixtures/beta5');a=p.parse_args()
def method(path,signature):
 s=path.read_text();start=s.index(signature);i=s.index('{',start)+1;depth=1
 while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[start:i]
relative='src/customTypes/TargetManager.cpp';current=method(root/relative,'void TargetManager::Initialize()')
old=method(a.baseline_source/relative,'void TargetManager::Initialize()').replace('TargetManager::Initialize()','TargetManager::InitializeOriginal()')
relative='src/AvatarManager.cpp';finger=method(root/relative,'void AvatarManager::SetFingerPose(')
oldfinger=method(a.baseline_source/relative,'void AvatarManager::SetFingerPose(').replace('AvatarManager::SetFingerPose(','AvatarManager::SetFingerPoseOriginal(')
init=method(root/'src/customTypes/FinalIK/VRIK.cpp','void VRIK::Initiate()')
disable=method(root/'src/customTypes/FinalIK/VRIK.cpp','void VRIK::OnDisable()')
stubs=r'''
#include <cassert>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
struct Log {void error(const char*){}} VRMLogger;
namespace UnityEngine {
 struct Animator{};struct Transform{void SetParent(Transform*,bool){}};
 struct GameObject {
  Transform trans;Transform* transform=&trans;
  static inline std::vector<std::unique_ptr<GameObject>> owned;
  static GameObject* New_ctor(){owned.push_back(std::make_unique<GameObject>());return owned.back().get();}
  template<class T>T AddComponent(){return {};}
 };
}
namespace VRMQavatars {
struct GroundOffsetObject{};
namespace FinalIK {
 struct VRIK {
  bool componentInitiated=false,calibrating=false,detected=false;
  UnityEngine::Animator available;UnityEngine::Animator* animator=nullptr;
  UnityEngine::Transform transformObject;UnityEngine::Transform* transform=&transformObject;
  int initiations=0;
  void AutoDetectReferences(){detected=true;}
  void set_enabled(bool value){if(!value)OnDisable();}
  void FindAnimatorRecursive(UnityEngine::Transform*,bool){animator=&available;}
  void VRIK_InitiateSolver(){assert(animator&&detected);++initiations;}
  void Initiate();void OnDisable();
 };
}
struct TargetManager {
 FinalIK::VRIK* vrik;UnityEngine::GameObject object;
 UnityEngine::GameObject* gameObject=&object;UnityEngine::Transform* transform=object.transform;
 UnityEngine::GameObject *leftHandTarget,*rightHandTarget,*headTarget,*waistTracker,*chestTracker,*leftFootTracker,*rightFootTracker,*leftKneeTracker,*rightKneeTracker;
 void Initialize();void InitializeOriginal();
};
struct HandController {
 static inline int calls=0;
 static void ApplyHandPose(UnityEngine::Animator* animator,const std::string&){if(!animator)throw std::runtime_error("null Animator would be dereferenced by finger setup");++calls;}
};
struct AvatarManager {static inline FinalIK::VRIK* vrik=nullptr;static void SetFingerPose(const std::string&);static void SetFingerPoseOriginal(const std::string&);};
'''
main=r'''
}
int main(){using namespace VRMQavatars;
 FinalIK::VRIK original;TargetManager old;old.vrik=&original;old.InitializeOriginal();AvatarManager::vrik=&original;
 assert(original.animator==nullptr && original.initiations==0);
 bool reproduced=false;try{AvatarManager::SetFingerPoseOriginal("pose");}catch(const std::runtime_error&){reproduced=true;}
 assert(reproduced);std::cout<<"Original beta.5 load sequence reaches finger setup with null Animator.\n";
 FinalIK::VRIK fixed;TargetManager now;now.vrik=&fixed;now.Initialize();AvatarManager::vrik=&fixed;
 assert(fixed.animator!=nullptr && fixed.componentInitiated && fixed.initiations==1);
 AvatarManager::SetFingerPose("pose");assert(HandController::calls==1);
 fixed.calibrating=true;fixed.componentInitiated=false;fixed.OnDisable();fixed.Initiate();assert(fixed.initiations==1);
 fixed.calibrating=false;fixed.Initiate();assert(fixed.initiations==2);
 FinalIK::VRIK uninitialized;AvatarManager::vrik=&uninitialized;AvatarManager::SetFingerPose("pose");assert(HandController::calls==1);
 AvatarManager::vrik=nullptr;AvatarManager::SetFingerPose("pose");assert(HandController::calls==1);
 std::cout<<"Explicit load initialization, finger setup, calibration guard and missing Animator checks passed (ASan/UBSan). Unity runtime not simulated.\n";
}
'''
with tempfile.TemporaryDirectory() as tmp:
 tmp=Path(tmp);cpp=tmp/'load.cpp';exe=tmp/'load-test'
 cpp.write_text(stubs+'\nnamespace FinalIK {\n'+init+'\n'+disable+'\n}\n'+current+'\n'+old+'\n'+finger+'\n'+oldfinger+main)
 subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(cpp),'-o',str(exe)],check=True)
 import os
 subprocess.run([str(exe)],check=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
