#!/usr/bin/env python3
"""Compile actual Spine/Leg/VirtualBone/BodyPart methods with host math/Transform stubs.

Checks native positions/rotations, not IL2CPP, Unity skinning or real tracking.
Arm reach is the actual Stretching method with a minimal Arm holder, not Arm::Solve.
"""
from pathlib import Path
import os,shutil,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
def clean(p):return '\n'.join(l for l in p.read_text().splitlines() if not l.startswith('#include') and not l.startswith('#pragma'))
def extract(text,signature):
 start=text.index(signature);i=text.index('{',start)+1;depth=1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[start:i]
h=(root/'tests/host/spine-math.hpp').read_text()+'\n'+clean(root/'include/customTypes/FinalIK/VR/ArmReachGuard.hpp')
for n in ['VR/VirtualBone','VR/BodyPart','VR/Leg']:h+='\n'+clean(root/('include/customTypes/FinalIK/'+n+'.hpp'))
h+='''\nnamespace VRMQavatars::FinalIK {struct Arm {Sombrero::FastVector3 position;std::vector<VirtualBone*> bones;float armLengthMlp=1,positionWeight=1;VirtualBone* upperArm(){return bones[0];}VirtualBone* forearm(){return bones[1];}VirtualBone* hand(){return bones[2];}void Stretching();};}\n'''
for n in ['VR/Spine','V3Tools','QuaTools','MathUtil']:h+='\n'+clean(root/('include/customTypes/FinalIK/'+n+'.hpp'))
for n in ['VR/VirtualBone','VR/BodyPart','VR/Leg','V3Tools','QuaTools','VR/Spine']:h+='\n'+clean(root/('src/customTypes/FinalIK/'+n+'.cpp'))
arm=extract((root/'src/customTypes/FinalIK/VR/Arm.cpp').read_text(),'void Arm::Stretching()')
h+='\nnamespace VRMQavatars::FinalIK {\n'+arm+'\n}\n'
main=r'''
int main(){using namespace VRMQavatars::FinalIK;using V=Sombrero::FastVector3;using Q=Sombrero::FastQuaternion;
 for(bool hc:{false,true})for(bool hn:{false,true})for(float scale:{.75f,1.f,1.4f})for(float drop:{0.f,.2f,.5f,.8f}){
 Spine s{};Leg l{},r{};Arm la{},ra{};UnityEngine::Transform ht{{0,1.7f*scale-drop*scale,0},{}};s.headTarget=&ht;s.minHeadHeight=-10;s.maintainPelvisPosition=0;s.maxRootAngle=180;
 std::vector<V> p(22);std::vector<Q> q(22);p[1]={0,1,0};p[2]={0,1.2f,0};p[3]={0,1.4f,0};p[4]={0,1.58f,0};p[5]={0,1.7f,0};p[14]={-.1f,.95f,0};p[15]={-.1f,.5f,.02f};p[16]={-.1f,.05f,0};p[18]={.1f,.95f,0};p[19]={.1f,.5f,.02f};p[20]={.1f,.05f,0};for(auto& v:p)v*=scale;
 s.Read(p,q,hc,hn,true,false,true,0,1);l.Read(p,q,true,true,true,false,true,1,14);r.Read(p,q,true,true,true,false,true,1,18);
 la.position=V{-.6f,1.4f,0}*scale;ra.position=V{.6f,1.4f,0}*scale;s.PreSolve();l.PreSolve();r.PreSolve();s.ApplyOffsets();VirtualBone rb({},{});s.Solve(&rb,{&l,&r},{&la,&ra});
 l.ApplyOffsets();r.ApplyOffsets();for(int j=0;j<2;j++){s.InverseTranslateToHead({&l,&r},true,true,{},1);for(auto* leg:{&l,&r}){leg->TranslateRoot(s.pelvis()->solverPosition,s.pelvis()->solverRotation);leg->Solve(j==0);}}
 auto out=p;auto rot=q;s.Write(out,rot);l.Write(out,rot);r.Write(out,rot);
 // The final output written to Unity must carry the whole solved spine, not
 // leave chest/neck/head positions in the standing read pose.
 assert(out[1].Distance(s.pelvis()->solverPosition)<1e-5f);assert(out[2].Distance(s.firstSpineBone()->solverPosition)<1e-5f);if(hc)assert(out[3].Distance(s.chest()->solverPosition)<1e-5f);if(hn)assert(out[4].Distance(s.neck()->solverPosition)<1e-5f);assert(out[5].Distance(s.head()->solverPosition)<1e-5f);
 assert(std::isfinite(out[1].y));if(drop>.1f)assert(out[1].y<p[1].y-drop*scale*.45f);
 assert(out[5].Distance(ht.position)<.001f);
 assert(out[16].Distance(p[16])<.002f && out[20].Distance(p[20])<.002f);
 std::vector<int> chain{1,2};if(hc)chain.push_back(3);if(hn)chain.push_back(4);chain.push_back(5);for(int i=1;i<chain.size();i++)assert(std::abs(out[chain[i-1]].Distance(out[chain[i]])-p[chain[i-1]].Distance(p[chain[i]]))<.002f);
 std::cout<<"chest="<<hc<<" neck="<<hn<<" scale="<<scale<<" drop="<<drop<<" pelvis="<<out[1].y<<" head_error="<<out[5].Distance(ht.position)<<"\n";
 for(auto* part:{static_cast<BodyPart*>(&s),static_cast<BodyPart*>(&l),static_cast<BodyPart*>(&r)})for(auto* b:part->bones)delete b;
 }
 for(float reach:{.8f,1.f,1.2f,1.6f,3.f}){
 VirtualBone a({0,0,0},{}),b({.5f,0,0},{}),c({1,0,0},{});Arm arm;arm.bones={&a,&b,&c};arm.position={reach,0,0};arm.Stretching();
 const float expected=std::clamp(reach,1.f,1.3f);assert(std::abs(c.solverPosition.x-expected)<1e-5f);assert(b.solverPosition.Distance(a.solverPosition)>0);
 }
 for(float weight:{0.f,.5f,1.f}){
 VirtualBone a({0,0,0},{}),b({.5f,0,0},{}),c({1,0,0},{});Arm arm;arm.bones={&a,&b,&c};arm.position={1.4f,0,0};arm.positionWeight=weight;arm.Stretching();assert(std::abs(c.solverPosition.x-(1.f+.3f*weight))<1e-5f);
 }
 {VirtualBone a({},{}),b({},{}),c({},{});Arm arm;arm.bones={&a,&b,&c};arm.position={1,0,0};arm.Stretching();assert(std::isfinite(c.solverPosition.x));}
 std::cout<<"Actual native pose writeout, crouch, planted feet, 3 scales, arm reach and spike limit passed. Unity skinning not simulated.\n";
}
'''
compiler=os.environ.get('CXX') or shutil.which('clang++')
assert compiler,'Set CXX to a host Clang compiler (requires -fdeclspec).'
with tempfile.TemporaryDirectory() as tmp:
 tmp=Path(tmp)
 for label,code in [('fixed',h),('old-spine-write',h.replace('positions[index + 1] = bones[1]->solverPosition;','').replace('positions[index + 2] = bones[chestIndex]->solverPosition;','').replace('positions[index + 3] = bones[neckIndex]->solverPosition;','').replace('positions[index + 4] = bones[headIndex]->solverPosition;',''))]:
  cpp=tmp/(label+'.cpp');exe=tmp/label;cpp.write_text(code+main)
  subprocess.run([compiler,'-std=c++20','-fdeclspec','-Wno-ignored-attributes',str(cpp),'-o',str(exe)],check=True)
  result=subprocess.run([str(exe)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  if label=='fixed':
   print(result.stdout);print(result.stderr);assert result.returncode==0,result.returncode
  else:assert result.returncode!=0,'The negative control unexpectedly passed'
 print('Negative control: old spine position writeout fails, as expected.')
