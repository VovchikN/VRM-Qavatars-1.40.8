#!/usr/bin/env python3
"""Execute serialized MToon alpha blend states on host surfaceless EGL/GLES3.
Minimal fragment outputs model alpha 0/0.5/1 variants, not MToon lighting.
This proves blend arithmetic on the host driver, not Quest postprocessing.
"""
from pathlib import Path
import ctypes as c,json,sys
import UnityPy
root=Path(__file__).resolve().parents[1]
L=c.CDLL('libEGL.so.1')
def egl(name,result,args):
 f=getattr(L,name);f.restype=result;f.argtypes=args;return f
ptr=c.c_void_p;I=c.c_int;U=c.c_uint;F=c.c_float
get=egl('eglGetProcAddress',ptr,[c.c_char_p])
def gl(name,result,args):return c.CFUNCTYPE(result,*args)(get(name.encode()))
display=gl('eglGetPlatformDisplayEXT',ptr,[U,ptr,c.POINTER(I)])(0x31dd,None,None)
major=I();minor=I();assert egl('eglInitialize',I,[ptr,c.POINTER(I),c.POINTER(I)])(display,c.byref(major),c.byref(minor))
assert egl('eglBindAPI',I,[U])(0x30a0)
attrs=(I*15)(0x3033,1,0x3040,0x40,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038,0,0)
config=ptr();n=I();assert egl('eglChooseConfig',I,[ptr,c.POINTER(I),c.POINTER(ptr),I,c.POINTER(I)])(display,attrs,c.byref(config),1,c.byref(n)) and n.value
ctx=egl('eglCreateContext',ptr,[ptr,ptr,ptr,c.POINTER(I)])(display,config,None,(I*3)(0x3098,3,0x3038));assert ctx
surf=egl('eglCreatePbufferSurface',ptr,[ptr,ptr,c.POINTER(I)])(display,config,(I*5)(0x3057,4,0x3056,4,0x3038));assert surf
assert egl('eglMakeCurrent',I,[ptr,ptr,ptr,ptr])(display,surf,surf,ctx)
GetString=gl('glGetString',c.c_char_p,[U]);print('Renderer:',GetString(0x1f01).decode())
CreateShader=gl('glCreateShader',U,[U]);ShaderSource=gl('glShaderSource',None,[U,I,c.POINTER(c.c_char_p),c.POINTER(I)]);CompileShader=gl('glCompileShader',None,[U]);GetShaderiv=gl('glGetShaderiv',None,[U,U,c.POINTER(I)])
def shader(kind,source):
 s=CreateShader(kind);src=c.c_char_p(source.encode());ShaderSource(s,1,c.byref(src),None);CompileShader(s);ok=I();GetShaderiv(s,0x8b81,c.byref(ok));assert ok.value;return s
vs=shader(0x8b31,'#version 300 es\nvoid main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.-1.,0.,1.);}')
fs=shader(0x8b30,'#version 300 es\nprecision highp float;uniform float alpha;out vec4 col;void main(){col=vec4(.25,.5,.75,alpha);}')
program=gl('glCreateProgram',U,[])();attach=gl('glAttachShader',None,[U,U]);attach(program,vs);attach(program,fs);gl('glLinkProgram',None,[U])(program);ok=I();gl('glGetProgramiv',None,[U,U,c.POINTER(I)])(program,0x8b82,c.byref(ok));assert ok.value
gl('glUseProgram',None,[U])(program);location=gl('glGetUniformLocation',I,[U,c.c_char_p])(program,b'alpha')
Uniform=gl('glUniform1f',None,[I,F]);ClearColor=gl('glClearColor',None,[F,F,F,F]);Clear=gl('glClear',None,[U]);Enable=gl('glEnable',None,[U]);Disable=gl('glDisable',None,[U]);BlendFunc=gl('glBlendFuncSeparate',None,[U,U,U,U]);BlendEq=gl('glBlendEquationSeparate',None,[U,U]);Draw=gl('glDrawArrays',None,[U,I,I]);Read=gl('glReadPixels',None,[I,I,I,I,U,U,ptr]);Viewport=gl('glViewport',None,[I,I,I,I]);Mask=gl('glColorMask',None,[c.c_ubyte]*4);GetError=gl('glGetError',U,[]);Viewport(0,0,4,4)
def draw(src,dst,op,alpha,background,mask=15):
 Mask(1,1,1,1);Disable(0x0be2);ClearColor(.1,.1,.1,background);Clear(0x4000);Enable(0x0be2);Mask(bool(mask&8),bool(mask&4),bool(mask&2),bool(mask&1));BlendFunc(1,0,src,dst);BlendEq(0x8006,op);Uniform(location,alpha);Draw(4,0,3);pixel=(c.c_ubyte*4)();Read(1,1,1,1,0x1908,0x1401,pixel);assert GetError()==0;return list(pixel)
def load(path):
 for o in UnityPy.load(str(path)).objects:
  if o.type.name=='Shader':
   s=o.read()
   if s.m_ParsedForm.m_Name=='VRM/MToon':return s
 raise AssertionError('MToon missing')
s=load(root/'assets/shaders.sbund');basepasses=[p for sub in s.m_ParsedForm.m_SubShaders for p in sub.m_Passes if p.m_State.m_Name in ['FORWARD_BASE','FORWARD_BASE_ONLY_OUTLINE']];assert len(basepasses)==2
cases=0
for pas in basepasses:
 b=pas.m_State.rtBlend0
 assert b.srcBlend.name=='_SrcBlend' and b.destBlend.name=='_DstBlend' and b.blendOp.val==0
 assert (b.srcBlendAlpha.name,b.destBlendAlpha.name,b.blendOpAlpha.name)==('_AvatarAlphaSrc','_AvatarAlphaDst','_AvatarAlphaOp')
 for a in (0.,.5,1.):
  for bg in (0.,.2,1.):
   pixel=draw(0,0,0x8006,a,bg);assert pixel[3]==0,pixel;assert all(abs(x-y)<=1 for x,y in zip(pixel[:3],[64,128,191])),pixel;cases+=1
# Regression: old Max cannot clear background, A1 becomes full bloom.
assert draw(1,0,0x8008,0.,1.)[3]==255
assert draw(1,0,0x8008,1.,0.)[3]==255
# Alpha writes disabled in transparent+bloom case; preserve background.
assert abs(draw(0x0302,0x0303,0x8008,1.,.2,14)[3]-51)<=1
# Additive RGB pass must never reintroduce variant alpha.
assert all(p.m_State.rtBlend0.colMask.val==14 for sub in s.m_ParsedForm.m_SubShaders for p in sub.m_Passes if p.m_State.m_Name=='FORWARD_ADD')
report={'Quest_tested':False,'renderer':GetString(0x1f01).decode(),'gles_version':GetString(0x1f02).decode(),'base_and_outline_blend_cases':cases,'rgb_unchanged':True,'solid_bloom_alpha_zero_for_all_tested_outputs':True,'old_Max_negative_controls_reproduce_nonzero_alpha':True,'transparent_mask_preserves_alpha':True,'additive_pass_RGB_only':True,'scope':'Host fixed-function blend arithmetic with minimal shaders; does not test Unity state binding, MToon lighting or Quest postprocess'}
print(json.dumps(report,indent=2))
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n')
