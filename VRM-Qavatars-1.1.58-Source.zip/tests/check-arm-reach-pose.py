#!/usr/bin/env python3
"""Compile the real Arm/BodyPart/VirtualBone methods with math and Transform stubs.
Not a Unity/Quest, skinning, controller input or replay runtime test.
"""
from pathlib import Path
import os,shutil,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
def clean(p):return '\n'.join(l for l in p.read_text().splitlines() if not l.startswith(('#include','#pragma')))
h=(root/'tests/host/spine-math.hpp').read_text().replace(' static FastVector3 Lerp(', ' static FastVector3 Normalize(FastVector3 v){return v.normalized;}\n static FastVector3 Lerp(')
h+='\nnamespace UnityEngine {struct Time{static float get_deltaTime(){return 1.f/72;} static float get_unscaledDeltaTime(){return 1.f/72;}};}\n'
for n in ['Axis','InterpolationMode','VR/ArmReachGuard','VR/VirtualBone','VR/BodyPart','VR/Arm','VR/Leg','VR/Spine','V3Tools','QuaTools','MathUtil','AxisTools','Interp']:h+='\n'+clean(root/('include/customTypes/FinalIK/'+n+'.hpp'))
for n in ['VR/VirtualBone','VR/BodyPart','VR/Leg','VR/Spine','V3Tools','QuaTools','AxisTools','Interp','VR/Arm']:h+='\n'+clean(root/('src/customTypes/FinalIK/'+n+'.cpp'))
main=r'''
int main(){using namespace VRMQavatars::FinalIK;using V=Sombrero::FastVector3;using Q=Sombrero::FastQuaternion;
int cases=0;
for(bool shoulders:{false,true}) for(bool left:{false,true}) for(float scale:{.5f,1.f,1.8f}) for(float shoulderWeight:{0.f,1.f}) for(auto mode:{ShoulderRotationMode::YawPitch,ShoulderRotationMode::FromTo}) {
 Arm a{};a.shoulderRotationWeight=shoulderWeight;a.shoulderRotationMode=mode;a.wristToPalmAxis={0,0,1};a.palmToThumbAxis={0,1,0};
 std::vector<V> p(22);std::vector<Q> r(22);const int i=left?6:10;const float side=left?-1.f:1.f;
 p[3]={0,1.4f*scale,0};p[i]=V{side*.16f,1.4f,0}*scale;p[i+1]=V{side*.2f,1.4f,0}*scale;p[i+2]=V{side*.5f,1.4f,0}*scale;p[i+3]=V{side*.8f,1.4f,0}*scale;
 const float length=.6f*scale;UnityEngine::Transform tracked{p[i+1]+V{side*length*.98f,0,0},{}};a.target=&tracked;
 auto frame=[&](){a.Read(p,r,true,true,shoulders,false,true,3,i);a.PreSolve();a.ApplyOffsets();a.Solve(left);for(auto* b:a.bones)assert(std::isfinite(b->solverPosition.x)&&std::isfinite(b->solverPosition.y));};
 frame();assert(!a.reachGuard.detached);assert(a.hand()->solverPosition.Distance(tracked.position)<.003f);
 tracked.position=p[i+1]+V{side*length*1.15f,0,0};frame();assert(!a.reachGuard.detached);assert(a.hand()->solverPosition.Distance(tracked.position)<.003f);
 // New user regression: 25% extension must stay attached, including lowered arms.
 for(V direction:{V{side,0,0},V{side*.25f,-.95f,.18f}.normalized}) {
   tracked.position=p[i+1]+direction*(length*1.25f);
   for(int f=0;f<20;f++)frame();
   assert(!a.reachGuard.detached&&a.reachGuard.trackingWeight==1);
   assert(a.hand()->solverPosition.Distance(tracked.position)<.003f);
 }
 tracked.position=p[i+1]+V{side*length*3.f,0,0};auto unchanged=tracked.position;
 for(int f=0;f<40;f++){frame();const float actual=(a.forearm()->solverPosition-a.upperArm()->solverPosition).magnitude+(a.hand()->solverPosition-a.forearm()->solverPosition).magnitude;assert(actual<=length*1.3001f);assert(tracked.position==unchanged);}
 assert(a.reachGuard.detached&&a.reachGuard.trackingWeight==0);assert(a.position.y<p[i+1].y-length*.8f);assert((a.position-p[i+1]).magnitude<length);assert(a.hand()->solverPosition.Distance(a.position)<.003f);
 // Neutral hand follows the solved body rather than remaining in world space.
 a.Read(p,r,true,true,shoulders,false,true,3,i);a.PreSolve();V newRoot=V{1,1.2f,.5f}*scale;Q turn=Q::AngleAxis(90,V::up());a.TranslateRoot(newRoot,turn);V origin=a.upperArm()->solverPosition;a.Solve(left);V offset=turn*(V{side*.12f,-.88f,.16f}*length);assert(a.position.Distance(origin+offset)<.003f);assert(tracked.position==unchanged);
 // Back inside inner boundary: return to the controller, independently of target writes.
 tracked.position=p[i+1]+V{side*length*.95f,0,0};for(int f=0;f<40;f++)frame();assert(!a.reachGuard.detached&&a.reachGuard.trackingWeight==1);assert(a.hand()->solverPosition.Distance(tracked.position)<.003f);
 // Regression: Read sees the standing/rest chest; the crouched chest arrives
 // only after Spine::Solve / InverseTranslateToHead / TranslateRoot.
 for(float drop:{.15f,.45f,.75f}) for(float ratio:{.80f,.98f,1.08f}) {
   a.reachGuard.Reset();
   V crouch=V{0,-drop*scale,0};
   tracked.position=p[i+1]+crouch+V{side*length*ratio,0,0};
   V controllerUnchanged=tracked.position;
   for(int f=0;f<40;f++) {
     a.Read(p,r,true,true,shoulders,false,true,3,i);a.PreSolve();a.ApplyOffsets();
     a.TranslateRoot(p[3]+crouch,Q::identity());a.Solve(left);
     if(a.reachGuard.detached || a.reachGuard.trackingWeight!=1.f) {
       std::cerr<<"CROUCH_FALSE_RELEASE drop="<<drop<<" ratio="<<ratio<<" scale="<<scale<<"\n";return 2;
     }
     assert(a.hand()->solverPosition.Distance(tracked.position)<.003f);
     assert(tracked.position==controllerUnchanged);
   }
 }
 // Excess reach must still release the arm while crouched.
 a.reachGuard.Reset();V crouch=V{0,-.6f*scale,0};
 tracked.position=p[i+1]+crouch+V{side*length*1.6f,0,0};
 for(int f=0;f<40;f++) {
   a.Read(p,r,true,true,shoulders,false,true,3,i);a.PreSolve();a.ApplyOffsets();
   a.TranslateRoot(p[3]+crouch,Q::identity());a.Solve(left);
 }
 assert(a.reachGuard.detached && a.reachGuard.trackingWeight==0);
 assert(a.hand()->solverPosition.Distance(a.position)<.003f);
 // Invalid inputs cannot propagate NaNs into pose or modify the target.
 tracked.position.x=std::numeric_limits<float>::quiet_NaN();frame();assert(a.reachGuard.detached);assert(std::isfinite(a.position.x));assert(std::isfinite(a.rotation.w));
 for(auto* b:a.bones)delete b;++cases;
}
int wholeBodyCases=0;
for(float scale:{.75f,1.f,1.4f}) for(float drop:{0.f,.2f,.5f,.8f}) {
 Spine s{};Leg ll{},rl{};Arm la{},ra{};
 for(auto* a:{&la,&ra}){a->wristToPalmAxis={0,0,1};a->palmToThumbAxis={0,1,0};}
 std::vector<V> p(22);std::vector<Q> q(22);
 p[1]={0,1,0};p[2]={0,1.2f,0};p[3]={0,1.4f,0};p[4]={0,1.58f,0};p[5]={0,1.7f,0};
 p[6]={-.16f,1.4f,0};p[7]={-.2f,1.4f,0};p[8]={-.5f,1.4f,0};p[9]={-.8f,1.4f,0};
 p[10]={.16f,1.4f,0};p[11]={.2f,1.4f,0};p[12]={.5f,1.4f,0};p[13]={.8f,1.4f,0};
 p[14]={-.1f,.95f,0};p[15]={-.1f,.5f,.02f};p[16]={-.1f,.05f,0};p[18]={.1f,.95f,0};p[19]={.1f,.5f,.02f};p[20]={.1f,.05f,0};for(auto& v:p)v*=scale;
 UnityEngine::Transform head{V{0,1.7f-drop,0}*scale,{}},lt{V{-.76f,1.4f-drop,0}*scale,{}},rt{V{.76f,1.4f-drop,0}*scale,{}};
 s.headTarget=&head;s.minHeadHeight=-10;s.maintainPelvisPosition=0;s.maxRootAngle=180;la.target=&lt;ra.target=&rt;
 for(int f=0;f<30;f++) {
   s.Read(p,q,true,true,true,false,true,0,1);la.Read(p,q,true,true,true,false,true,3,6);ra.Read(p,q,true,true,true,false,true,3,10);
   ll.Read(p,q,true,true,true,false,true,1,14);rl.Read(p,q,true,true,true,false,true,1,18);
   s.PreSolve();la.PreSolve();ra.PreSolve();ll.PreSolve();rl.PreSolve();la.ApplyOffsets();ra.ApplyOffsets();s.ApplyOffsets();VirtualBone root({},{});
   s.Solve(&root,{&ll,&rl},{&la,&ra});ll.ApplyOffsets();rl.ApplyOffsets();
   for(int pass=0;pass<2;pass++){s.InverseTranslateToHead({&ll,&rl},true,true,{},1);for(auto* l:{&ll,&rl}){l->TranslateRoot(s.pelvis()->solverPosition,s.pelvis()->solverRotation);l->Solve(pass==0);}}
   for(auto* a:{&la,&ra}){a->TranslateRoot(s.chest()->solverPosition,s.chest()->solverRotation);a->Solve(a==&la);}
   if(la.reachGuard.detached||ra.reachGuard.detached){std::cerr<<"WHOLE_BODY_FALSE_RELEASE scale="<<scale<<" drop="<<drop<<"\n";return 3;}
   for(auto* a:{&la,&ra}){assert(a->reachGuard.trackingWeight==1);assert(a->hand()->solverPosition.Distance(a->target->position)<.003f);}
   la.ResetOffsets();ra.ResetOffsets();s.ResetOffsets();ll.ResetOffsets();rl.ResetOffsets();
 }
 for(auto* part:{static_cast<BodyPart*>(&s),static_cast<BodyPart*>(&ll),static_cast<BodyPart*>(&rl),static_cast<BodyPart*>(&la),static_cast<BodyPart*>(&ra)})for(auto* b:part->bones)delete b;
 ++wholeBodyCases;
}
std::cout<<wholeBodyCases<<" whole-body crouch scenarios passed with actual Spine, planted legs and Arm solve order.\n";
std::cout<<cases<<" actual Arm pose scenarios passed (both sides, shoulder/no-shoulder, three scales, shoulder weights/modes, release/reconnect/body motion/crouch/invalid tracking); Quest runtime not tested.\n";}
'''
compiler=os.environ.get('CXX') or shutil.which('clang++');assert compiler,'Set CXX to host-capable Clang'
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'test.cpp').write_text(h+main)
 subprocess.run([compiler,'-std=c++20','-fdeclspec','-Wno-ignored-attributes',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
 old=h.replace('ApplyReachGuard(index == 6, false);','ApplyReachGuard(index == 6, true);').replace('ApplyReachGuard(isLeft, true);','ApplyReachGuard(isLeft, false);')
 assert old!=h
 (p/'old.cpp').write_text(old+main)
 subprocess.run([compiler,'-std=c++20','-fdeclspec','-Wno-ignored-attributes',str(p/'old.cpp'),'-o',str(p/'old')],check=True)
 result=subprocess.run([str(p/'old')],capture_output=True,text=True)
 assert result.returncode==2 and 'CROUCH_FALSE_RELEASE' in result.stderr, result.stderr
 print('Negative control: beta.5.6 decision order reproduces false release during crouching.')
