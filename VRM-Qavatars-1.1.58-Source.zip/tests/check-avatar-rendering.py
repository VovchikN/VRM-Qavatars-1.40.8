#!/usr/bin/env python3
"""Actual material import/update methods with Unity stubs, not GPU/Quest rendering."""
from pathlib import Path
import subprocess,tempfile,os
r=Path(__file__).resolve().parents[1]
def clean(p):return '\n'.join(x for x in p.read_text().splitlines() if not x.startswith('#include'))
newgen=clean(r/'src/AssetLib/generators/materialGenerator.cpp');newtracker=clean(r/'src/MaterialTracker.cpp')
fix=r/'tests/fixtures/beta53-render';oldgen=clean(fix/'materialGenerator.cpp');oldtracker=clean(r/'tests/fixtures/beta54-render/MaterialTracker.cpp')
stubs=r'''
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <tuple>
#include <vector>
#include "utils/AvatarRenderPolicy.hpp"
struct Log{template<class...A>void info(const char*,A...){}} VRMLogger;
namespace Sombrero{struct FastColor{float r,g,b,a;FastColor(float x,float y,float z,float w):r(x),g(y),b(z),a(w){}};}
namespace UnityEngine {
struct Texture2D{};struct Shader{std::string get_name(){return "VRM/MToon";}};
struct Material {
 static inline std::vector<std::unique_ptr<Material>> owned;std::map<std::string,float>floats{{"_BlendMode",0},{"_ZWrite",1}};
 std::map<std::string,std::string>tags;std::map<std::string,Texture2D*>tex;std::map<std::string,Sombrero::FastColor>colors;std::set<std::string>keywords;int queue=-1;Shader* shader;
 static Material* New_ctor(Shader* s){owned.push_back(std::make_unique<Material>());auto* m=owned.back().get();m->shader=s;return m;}
 void SetFloat(std::string k,float v){floats[k]=v;}void SetInt(std::string k,int v){SetFloat(k,v);}float GetFloat(std::string k){return floats[k];}
 void EnableKeyword(std::string k){keywords.insert(k);}void DisableKeyword(std::string k){keywords.erase(k);}
 void SetTexture(std::string k,Texture2D* t){tex[k]=t;}void SetColor(std::string k,Sombrero::FastColor c){colors.insert_or_assign(k,c);}
 void SetOverrideTag(std::string k,std::string v){tags[k]=v;}void set_renderQueue(int q){queue=q;}std::string get_name(){return "material";}
};}
template<class T>struct SafePtrUnity {T* p=nullptr;SafePtrUnity()=default;SafePtrUnity(T* q):p(q){};operator bool()const{return p!=nullptr;}T* operator->(){return p;}};
namespace VRMC_VRM_0_0 {
using Props=std::tuple<std::string,std::string,int,std::map<std::string,float>,std::map<std::string,std::vector<float>>,std::map<std::string,int>,std::map<std::string,bool>,std::map<std::string,std::string>>;
struct Vrm{std::vector<Props>materialProperties;};}
namespace VRMC_VRM_1_0{struct Vrm{};}
namespace AssetLib {
struct ModelImporter{struct Ptr{UnityEngine::Shader shader;UnityEngine::Shader* ptr(){return &shader;}};static inline Ptr mtoon;};
namespace Generators {struct MaterialGenerator{template<class T>UnityEngine::Material* Generate(const T&,int,UnityEngine::Texture2D**);};}}
namespace VRMQavatars {
struct MaterialTracker{static bool bloomEnabled;static std::vector<SafePtrUnity<UnityEngine::Material>>materials;static void UpdateMaterials();};
struct MirrorManager{static inline bool mainMirror=false;static inline int updates=0;static void UpdateMirror(bool){++updates;}};
}
'''
main=r'''
int main(){using namespace VRMQavatars;using G=AssetLib::Generators::MaterialGenerator;
 for(float mode:{0.f,1.f,2.f,3.f,42.f,-1.f})for(int queue:{-1,0,2000,2450,2500,2501,3000,4000})for(bool bloom:{false,true}){
  VRMC_VRM_0_0::Vrm model;std::map<std::string,float>floats{{"_BlendMode",mode},{"_ZWrite",mode==3?1.f:0.f},{"_SrcBlend",5},{"_DstBlend",10},{"_Cutoff",.42f}};
  model.materialProperties.push_back({"shoe","VRM/MToon",queue,floats,{{"_Color",{1,.8f,.7f,.6f}}},{{"_MainTex",0}},{{"_ALPHABLEND_ON",true},{"_ALPHATEST_ON",false}},{{"RenderType","Transparent"}}});
  UnityEngine::Texture2D texture;UnityEngine::Texture2D* tex[]={&texture};G generator;auto* mat=generator.Generate(model,0,tex);bool solid=mode==0||mode==1;
  assert(mat->GetFloat("_Cutoff")==.42f&&mat->colors.at("_Color").a==.6f&&mat->tex["_MainTex"]==&texture);
  if(solid){assert(mat->GetFloat("_ZWrite")==1&&mat->GetFloat("_SrcBlend")==1&&mat->GetFloat("_DstBlend")==0);assert(mat->queue<=2500&&mat->queue>=0);assert(!mat->keywords.contains("_ALPHABLEND_ON"));assert(mat->keywords.contains("_ALPHATEST_ON")==bool(mode==1));assert(mat->tags["RenderType"]==(mode==0?"Opaque":"TransparentCutout"));}
  else{assert(mat->GetFloat("_ZWrite")==floats["_ZWrite"]&&mat->GetFloat("_SrcBlend")==5&&mat->GetFloat("_DstBlend")==10);assert(mat->queue==queue&&mat->keywords.contains("_ALPHABLEND_ON")&&mat->tags["RenderType"]=="Transparent");}
  MaterialTracker::materials={mat,nullptr};MaterialTracker::bloomEnabled=bloom;MirrorManager::mainMirror=true;int old=MirrorManager::updates;MaterialTracker::UpdateMaterials();assert(MirrorManager::updates==old+1);
  bool clear=bloom&&solid;assert(mat->GetFloat("_AvatarAlphaOp")==float(clear?0:4));assert(mat->GetFloat("_AvatarAlphaSrc")==float(clear?0:mat->GetFloat("_SrcBlend")));assert(mat->GetFloat("_AvatarAlphaDst")==float(clear?0:mat->GetFloat("_DstBlend")));
  assert(mat->GetFloat("_BloomSupport")==float(bloom));assert(mat->GetFloat("_ColorMask")==((!bloom||solid)?15:14));
 }
 for(float initial:{.1f,.5f,1.f})for(float shaderA:{0.f,.5f,1.f}){int mask=AvatarRenderPolicy::ColorMask(0,true);assert(mask&1);assert(AvatarRenderPolicy::ClearBloomAlpha(0,true));(void)initial;(void)shaderA;}
 assert(!AvatarRenderPolicy::IsSolid(std::numeric_limits<float>::quiet_NaN()));
 std::cout<<"Actual import/update methods: 48 material/queue states x 2 bloom states (96 cases); solid alpha/depth consistency, cutout preservation, transparent state preservation, mirror refresh and empty handles passed. This test does not execute GPU rendering. See separate EGL GPU blend regression.\n";
}
'''
with tempfile.TemporaryDirectory() as td:
 td=Path(td)
 for name,gen,tracker in [('fixed',newgen,newtracker),('old-alpha',newgen,oldtracker),('old-depth',oldgen,newtracker)]:
  p=td/(name+'.cpp');p.write_text(stubs+gen+tracker+main);exe=td/name
  subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(r/'include'),str(p),'-o',str(exe)],check=True)
  result=subprocess.run([str(exe)],capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
  if name=='fixed':print(result.stdout);print(result.stderr);assert result.returncode==0
  else:assert result.returncode!=0;print('Negative control',name,'fails as expected.')
