#!/usr/bin/env python3
"""Run actual native reset/init bodies with ownership stubs under ASan/UBSan.

This checks ownership and state invalidation only, not Unity or pose solving.
"""
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]

def method(path, name):
    text = path.read_text()
    match = re.search(r'void ' + re.escape(name) + r'\([^\n]*\)\s*\{', text)
    assert match, name
    end, depth = match.end(), 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[match.start():end]

reset = method(root / 'src/customTypes/FinalIK/IKSolverVR.cpp', 'IKSolverVR::Reset')
init = method(root / 'src/customTypes/FinalIK/VR/Locomotion.cpp', 'Locomotion::Initiate')
stubs = r'''
#include <cassert>
#include <iostream>
#include <vector>
namespace Sombrero {
struct FastVector3 {
 float x=0,y=0,z=0;
 static FastVector3 zero(){return {};}
 static FastVector3 left(){return {-1,0,0};}
 static FastVector3 right(){return {1,0,0};}
 FastVector3 operator*(float s)const{return {x*s,y*s,z*s};}
};
struct FastQuaternion {};
}
namespace VRMQavatars::FinalIK {
struct VirtualBone {static inline int alive=0;VirtualBone(){++alive;}~VirtualBone(){--alive;}};
struct BodyPart {
 std::vector<VirtualBone*> bones; bool initiated=true;float mag=1,sqrMag=1;
 int resetCalls=0;float preservedWeight=.75f;void* preservedTarget=reinterpret_cast<void*>(1);
 void ResetOffsets(){++resetCalls;}
};
struct Spine:BodyPart{Sombrero::FastVector3 locomotionHeadPositionOffset{1,2,3};};
struct Arm:BodyPart{};struct Leg:BodyPart{};
struct IKSolverVR {
 bool initiated=true,firstInitiation=false;
 Spine* spine;Arm *leftArm,*rightArm;Leg *leftLeg,*rightLeg;
 VirtualBone* rootBone;Sombrero::FastVector3 rootVelocity,bodyOffset,lastOffset,raycastOriginPelvis;
 int supportLegIndex=0,lastLOD=0,LOD=2;void Reset();
};
struct Footstep {
 static inline int alive=0;
 Footstep(Sombrero::FastQuaternion,Sombrero::FastVector3,Sombrero::FastQuaternion,Sombrero::FastVector3){++alive;}
 ~Footstep(){--alive;}
};
struct Locomotion {
 int leftFootIndex=0,rightFootIndex=0,resetCalls=0;float footDistance=.1f;
 std::vector<Footstep*> footsteps;
 void Reset(std::vector<Sombrero::FastVector3>,std::vector<Sombrero::FastQuaternion>){++resetCalls;}
 void Initiate(std::vector<Sombrero::FastVector3>,std::vector<Sombrero::FastQuaternion>,bool);
};
'''
main = r'''
}
int main(){
 using namespace VRMQavatars::FinalIK;
 Spine spine;Arm leftArm,rightArm;Leg leftLeg,rightLeg;
 IKSolverVR solver;solver.spine=&spine;solver.leftArm=&leftArm;solver.rightArm=&rightArm;
 solver.leftLeg=&leftLeg;solver.rightLeg=&rightLeg;solver.rootBone=new VirtualBone;
 for(BodyPart* p:{static_cast<BodyPart*>(&spine),static_cast<BodyPart*>(&leftArm),
   static_cast<BodyPart*>(&rightArm),static_cast<BodyPart*>(&leftLeg),static_cast<BodyPart*>(&rightLeg)}){
   for(int i=0;i<3;++i)p->bones.push_back(new VirtualBone);
 }
 assert(VirtualBone::alive==16);
 solver.Reset();solver.Reset();
 assert(VirtualBone::alive==0 && solver.rootBone==nullptr);
 assert(!solver.initiated && solver.firstInitiation && solver.supportLegIndex==-1);
 for(BodyPart* p:{static_cast<BodyPart*>(&spine),static_cast<BodyPart*>(&leftArm),
   static_cast<BodyPart*>(&rightArm),static_cast<BodyPart*>(&leftLeg),static_cast<BodyPart*>(&rightLeg)}){
   assert(p->bones.empty() && !p->initiated && p->resetCalls==2);
   assert(p->preservedWeight==.75f && p->preservedTarget==reinterpret_cast<void*>(1));
 }
 Locomotion locomotion;std::vector<Sombrero::FastVector3> positions(22);
 std::vector<Sombrero::FastQuaternion> rotations(22);
 for(int i=0;i<20;++i){
   locomotion.Initiate(positions,rotations,i%2==0);
   assert(Footstep::alive==2 && locomotion.footsteps.size()==2);
 }
 assert(locomotion.resetCalls==20);
 for(auto* p:locomotion.footsteps)delete p;
 assert(Footstep::alive==0);
 std::cout<<"Native reset/init ownership checks passed (ASan/UBSan); Unity poses not simulated.\n";
}
'''
with tempfile.TemporaryDirectory() as temporary:
    directory = Path(temporary)
    cpp, binary = directory / 'reset.cpp', directory / 'reset-test'
    cpp.write_text(stubs + reset + '\n' + init + '\n' + main)
    subprocess.run(['g++','-std=c++20','-O1','-g','-fsanitize=address,undefined',
                    '-fno-omit-frame-pointer',str(cpp),'-o',str(binary)],check=True)
    subprocess.run([str(binary)],check=True)
