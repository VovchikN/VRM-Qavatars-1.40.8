#include "utils/CalibrationMath.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
#include <limits>

int main() {
    using VRMQavatars::CalibrationMath::ScaleRatio;
    const auto near = [](float a, float b) { return std::abs(a - b) < 0.00001f; };
    // A shorter and a taller user's head must produce different scales.
    assert(near(ScaleRatio(1.50f, 1.25f).value(), 1.20f));
    assert(near(ScaleRatio(1.80f, 1.25f).value(), 1.44f));
    const auto once = ScaleRatio(1.80f, 1.25f).value();
    // Unit conversion of both inputs preserves their ratio.
    assert(near(ScaleRatio(180.0f, 125.0f).value(), once));
    assert(!ScaleRatio(0.0f, 1.25f));
    assert(!ScaleRatio(-1.0f, 1.25f));
    assert(!ScaleRatio(1.80f, 0.0f));
    assert(!ScaleRatio(std::numeric_limits<float>::quiet_NaN(), 1.25f));
    assert(!ScaleRatio(1.80f, std::numeric_limits<float>::infinity()));
    std::cout << "Calibration ratio tests passed; Unity/IK integration is not simulated.\n";
}
