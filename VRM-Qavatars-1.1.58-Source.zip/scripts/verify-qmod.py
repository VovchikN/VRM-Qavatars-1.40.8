#!/usr/bin/env python3
"""Check package structure and ARM64 ELF files. This is not a Quest runtime test."""
import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import tempfile
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('qmod', type=pathlib.Path)
args = parser.parse_args()
report = {'package': args.qmod.name, 'sha256': hashlib.sha256(args.qmod.read_bytes()).hexdigest(),
          'runtime_tested': False, 'libraries': {}}
with zipfile.ZipFile(args.qmod) as archive, tempfile.TemporaryDirectory() as tmp:
    names = archive.namelist()
    assert len(names) == len(set(names)), 'Duplicate ZIP entries'
    assert archive.testzip() is None, 'ZIP CRC failed'
    assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
    mod = json.loads(archive.read('mod.json'))
    assert mod['packageId'] == 'com.beatgames.beatsaber'
    assert mod['packageVersion'] == '1.40.8_7379'
    assert mod['modloader'] == 'Scotland2'
    assert 'libvrm-qavatars.so' in mod['lateModFiles']
    assert not mod.get('modFiles'), 'Scotland2 mod must load late'
    assert mod['dependencies'], 'Missing runtime dependency metadata'
    for dep in mod['dependencies']:
        assert dep['id'] and dep['version']
    for field in ('modFiles', 'lateModFiles', 'libraryFiles'):
        for name in mod.get(field, []):
            assert name in names, f'Missing {name}'
    for name in names:
        if not name.endswith('.so'):
            continue
        data = archive.read(name)
        assert data[:6] == b'\x7fELF\x02\x01', f'{name}: not ELF64 LE'
        assert int.from_bytes(data[16:18], 'little') == 3, f'{name}: not a shared ELF object'
        assert int.from_bytes(data[18:20], 'little') == 183, f'{name}: not AArch64'
        path = pathlib.Path(tmp, pathlib.PurePosixPath(name).name)
        path.write_bytes(data)
        dynamic = subprocess.check_output(['readelf', '-d', str(path)], text=True)
        assert 'TEXTREL' not in dynamic, f'{name}: text relocations'
        needed = re.findall(r'\(NEEDED\).*?\[(.*?)\]', dynamic)
        assert all('/' not in lib for lib in needed), f'{name}: absolute dependency path'
        for rpath in re.findall(r'\((?:RPATH|RUNPATH)\).*?\[(.*?)\]', dynamic):
            assert '/workspace/' not in rpath and '/root/' not in rpath, f'{name}: build-machine search path'
        symbols = subprocess.check_output(['readelf', '--dyn-syms', '--wide', str(path)], text=True)
        if name == 'libvrm-qavatars.so':
            for entry in ('setup', 'late_load'):
                assert re.search(r'GLOBAL\s+DEFAULT\s+\d+\s+' + entry + r'\s*$', symbols, re.M), f'Missing export {entry}'
        report['libraries'][name] = {
            'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
            'needed': re.findall(r'\(NEEDED\).*?\[(.*?)\]', dynamic),
            'soname': re.findall(r'\(SONAME\).*?\[(.*?)\]', dynamic)}
    report['manifest'] = mod
print(json.dumps(report, indent=2))
