#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to Android NDK r27c or a compatible r27 installation}"
QPM_BIN="${QPM_BIN:-qpm}"
mkdir -p build-logs
"$QPM_BIN" config ndk-path "$ANDROID_NDK_HOME"
"$QPM_BIN" restore 2>&1 | tee build-logs/restore.log
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-24 \
  2>&1 | tee build-logs/configure.log
cmake --build build --parallel "${BUILD_JOBS:-2}" 2>&1 | tee build-logs/build.log
"$QPM_BIN" qmod manifest --offline 2>&1 | tee build-logs/manifest.log
python3 tools/package-qmod.py 2>&1 | tee build-logs/package.log
