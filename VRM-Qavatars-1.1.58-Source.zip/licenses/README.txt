Third-party texts retained for VRM Qavatars 1.1.58 (2026-11-01).

These files are notices/evidence, not a grant of rights beyond their own terms.
Unconfirmed components remain unconfirmed. See docs/LICENSE_REPORT_EN.md in the accompanying source archive and
THIRD_PARTY_NOTICES.txt. The root MIT does not cover every component.

sombrero 0.1.43 is LGPL-2.1. The exact unchanged source is provided in the full
source archive at source/third_party/sombrero-0.1.43. After QPM restore, run
python tools/use-local-sombrero.py, edit that source and rebuild with CMake/NDK.
Provide matching source/rebuild materials alongside any redistributed binary.

Meta page texts preserve published conditions for review. The header names
Audio SDK License 3.3, while Meta says that historical text is superseded.
Do not infer verified binary provenance or unconditional permission from the
presence of either text. No Meta/Unity/RootMotion rights are granted by this port.
