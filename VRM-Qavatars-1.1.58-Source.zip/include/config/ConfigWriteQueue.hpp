#pragma once
#include <chrono>
#include <set>
#include <utility>

namespace VRMQavatars::Config {
// Main-thread UI write coalescing. Values/events remain immediate in memory.
// Flush before switching avatar config, leaving settings or changing scene.
class ConfigWriteQueue {
    using Clock = std::chrono::steady_clock;
    using Save = void(*)();
    static inline bool editing = false;
    static inline std::set<Save> pending;
    static inline Clock::time_point lastEdit{};
public:
    static void Begin() { editing = true; }
    static void Request(Save save, Clock::time_point now = Clock::now()) {
        if (!editing) { save(); return; }
        pending.insert(save);
        lastEdit = now;
    }
    static void Flush() {
        auto batch = std::move(pending);
        pending.clear();
        for (auto save : batch) save();
    }
    static void Tick(Clock::time_point now = Clock::now()) {
        if (!pending.empty() && now - lastEdit >= std::chrono::milliseconds(250)) Flush();
    }
    static void End() { Flush(); editing = false; }
};
}
