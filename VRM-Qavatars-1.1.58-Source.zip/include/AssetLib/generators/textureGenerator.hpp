#pragma once

#include "UnityEngine/Texture2D.hpp"
#include "json.hpp"
#include <vector>

namespace AssetLib::Generators
{
    class TextureGenerator
    {
        public:
        TextureGenerator() = default;
        ~TextureGenerator() = default;

        // Keep encoded bytes in native memory until the main-thread decode.
        std::vector<SafePtrUnity<UnityEngine::Texture2D>> Generate(const std::vector<std::vector<uint8_t>>& images);
    };
};
