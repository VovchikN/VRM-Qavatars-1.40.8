#pragma once
#include <algorithm>
#include <cmath>

namespace VRMQavatars::FinalIK {
// Dimensionless limits follow the avatar's calibrated world-space arm length.
// No controller/saber Transform is modified. Each Arm owns its own state.
struct ArmReachGuard {
    static constexpr float MaxReach = 1.30f;
    static constexpr float ReconnectReach = 1.25f;
    static constexpr float BlendSeconds = 0.20f;
    bool detached = false;
    float trackingWeight = 1.0f;

    void Reset() { detached = false; trackingWeight = 1.0f; }
    float Update(float ratio, float dt) {
        if (!std::isfinite(ratio) || ratio < 0.0f || ratio > MaxReach) detached = true;
        else if (detached && ratio <= ReconnectReach) detached = false;
        if (!std::isfinite(dt) || dt < 0.0f) dt = 0.0f;
        const float step = std::min(dt, 0.10f) / BlendSeconds;
        trackingWeight = detached ? std::max(0.0f, trackingWeight - step)
                                  : std::min(1.0f, trackingWeight + step);
        return trackingWeight;
    }
    static float StretchMultiplier(float requested, float weight) {
        if (!std::isfinite(requested)) requested = 1.0f;
        if (!std::isfinite(weight)) weight = 0.0f;
        return 1.0f + (std::clamp(requested, 1.0f, MaxReach) - 1.0f) * std::clamp(weight, 0.0f, 1.0f);
    }
};
}
