#pragma once
#include <cmath>
#include <optional>

namespace VRMQavatars::CalibrationMath {
    inline bool IsValidScale(float value) {
        return std::isfinite(value) && value > 0.0f;
    }

    // Both measurements are distances from the same floor/reference plane.
    inline std::optional<float> ScaleRatio(float trackedDistance, float avatarDistance) {
        if (!std::isfinite(trackedDistance) || !std::isfinite(avatarDistance)
            || trackedDistance <= 0.0f || avatarDistance <= 0.0001f) return std::nullopt;
        const float scale = trackedDistance / avatarDistance;
        return IsValidScale(scale) ? std::optional<float>(scale) : std::nullopt;
    }
}
