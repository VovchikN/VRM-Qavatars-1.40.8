#pragma once
namespace VRMQavatars::AvatarRenderPolicy {
// MToon BlendMode: 0 Opaque, 1 Cutout, 2 Transparent, 3 TransparentWithZWrite.
inline bool IsSolid(float blendMode) { return blendMode == 0.0f || blendMode == 1.0f; }
inline int ColorMask(float blendMode, bool bloom) {
    // Solid surfaces clear destination bloom alpha using independent Add(0,0).
    // Do not rely on the fragment output: several variants emit A=1.
    return !bloom || IsSolid(blendMode) ? 15 : 14;
}
inline bool ClearBloomAlpha(float blendMode, bool bloom) { return bloom && IsSolid(blendMode); }
inline int SolidQueue(float blendMode, int queue) {
    if (!IsSolid(blendMode)) return queue;
    return queue >= 0 && queue <= 2500 ? queue : (blendMode == 1.0f ? 2450 : 2000);
}
}
