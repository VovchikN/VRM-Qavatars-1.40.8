# VRM Qavatars

Experimental standalone Quest port for **Beat Saber 1.40.8_7379 / Scotland2**.
This build has not been tested on a physical Quest. Compilation and package
validation do not establish runtime compatibility. See the accompanying
Russian porting report and device checklist for the exact validation scope.

Use the accompanying `assimp-5.3.3-Scotland2-1.40.8.qmod`, or keep it installed
if already present. The upstream Assimp QMod has legacy loader metadata and
can prompt QuestPatcher to switch to QuestLoader; keep Scotland2 instead.

- Custom Avatars For Quest!
## Calibration and settings (beta.5.3)

The main **Recalibrate** button follows Calibration Type. **Match Armspans**
worked for the tester: hold both arms horizontally apart during the countdown.
**Fit Height (optional)** explicitly uses height and remains separate.

UI settings now update values immediately, with config writes coalesced after
250 ms idle and flushed on exit, scene/config switch. Settings application no
longer calls an extra IK solve outside the normal frame update. Shoulder weight,
IK reset and saturation refresh were corrected. Mirror physical size reuses the
existing render target while its pixel dimensions remain the same.

The added camera depth pass is now two-sided with Offset -1,-1; this is an
experimental attempt to reduce remaining below-knee distortion. No Quest GPU
test has been performed. Color passes and GPU programs are preserved.

Full third-party conditions are listed in the accompanying LICENSE_REPORT_RU.html.
The package has unresolved licensing/provenance questions and is not certified
for public redistribution. sombrero is LGPL-2.1 (not MIT); exact sources and a
rebuild selector are included under third_party and tools/use-local-sombrero.py.

## Features
- Full VRM 0.0 format support
- Replay Support (No third person support for now)
- Large list of customizable options and features ( All features documented at **https://bsq-vrm.github.io/documentation/**)
- Full Body tracking/Virtual Motion Capture support
- A feature rich mirror to show off your avatar in recordings
- Expression Triggers
- Playable Performance
- And a ton more, with even more in the future
## Support
- I have a optional support discord for sharing vrms you've made and getting updates on development (Linked in documentation^^)
- Otherwise you can stay updated here/on github and send me a dm with any issues
## Building
Use Android NDK r27c (27.2.12479018), QPM CLI 1.5.12, CMake and Ninja.
For Linux/WSL, export `ANDROID_NDK_HOME`, put CMake/Ninja/QPM in `PATH`, then run:

```bash
bash scripts/build-linux.sh
python3 scripts/verify-qmod.py VRM-Qavatars-1.40.8-beta.4.qmod
```

`QPM_BIN` can point to a QPM executable outside PATH; `BUILD_JOBS` defaults to 2.
The existing PowerShell scripts are retained for Windows. The Linux script
packages with `qpm qmod zip --skip_build --offline` after building natively.
Dependency versions are pinned in `qpm.json` and `qpm.shared.json`.

Upstream limitations remain: VRM 1.0 material generation is a stub; the
experimental microphone lip-sync components are not attached to avatars by
default. Controller expressions and automatic blinking are separate features.
The original Unity 2019.4.18f1 shader AssetBundle is retained and requires
validation with the target game.

## Credits

* [zoller27osu](https://github.com/zoller27osu), [Sc2ad](https://github.com/Sc2ad) and [jakibaki](https://github.com/jakibaki) - [beatsaber-hook](https://github.com/sc2ad/beatsaber-hook)
* [FrozenAlex](https://github.com/FrozenAlex/) for making me do this
* [HardCPP](https://github.com/hardcpp) for [ChatPlex-SDK](https://github.com/hardcpp/QuestChatPlexSDK-BS)
* [RedBrumbler](https://github.com/RedBrumbler/) for helping me debug lots of issues early on
* [Lauriethefish](https://github.com/Lauriethefish), [danrouse](https://github.com/danrouse) and [Bobby Shmurner](https://github.com/BobbyShmurner) for [this template](https://github.com/Lauriethefish/quest-mod-template)

## Beta.5.1 load crash fix

TargetManager explicitly initializes VRIK before AvatarManager applies the finger
pose. Beta.5 had removed initialization from OnDisable but still relied on its
side effect to populate VRIK::animator. A null Animator could reach hand setup
while loading an avatar. AvatarManager and HandController now also guard that
boundary. Skeletal, calibration and shader changes from beta.5 are retained.

Regression: `python tests/check-avatar-load-order.py` runs the actual method
bodies with Unity/solver stubs and the beta.5 control fixtures under ASan/UBSan.
It reproduces the old missing-Animator path; it does not run the real game.

## Beta.5

Full spine position writeout, vertical crouch following, native arm reach, local
rest pose and committed preview scale. The avatar selection page shows measured
Head / Model / Scale after calibration. Match Head Height remains the default;
Fixed remains manual. The shader bundle from beta.4-depth-test is retained.
Opaque/cutout materials incorrectly queued above 2500 are put in depth-compatible
queues; genuine transparent materials retain their queue. Quest validation pending.

Build: set ANDROID_NDK_HOME to NDK r27c and put CMake/Ninja/QPM on PATH;
run qpm restore, configure CMake with Ninja for Android arm64-v8a API 24, and
cmake --build build --parallel 4. Generate mod.json with qpm qmod manifest --offline
and package using python tools/package-qmod.py.

Additional host regression: set CXX to a host Clang (NDK clang++ can target the
host), then run python tests/check-spine-pose.py. It compiles actual native
solver methods with host math/Transform stubs; it does not run Unity/IL2CPP.
The top-level REPORT_RU.md in the full archive describes changes and Quest tests.

## Bloom regression fix (beta.5.5)

beta.5.4 produced a white/glowing avatar on the user's Quest. Enabling RGBA
was insufficient: bundled shader variants include alpha=1 outputs, and base /
outline passes used Max alpha blending. That state could preserve background
bloom or make the avatar a bloom source.

With bloom enabled, Opaque/Cutout now use independent Add(Zero, Zero) alpha
blending in both base passes. RGB factors, lighting programs and depth code
are unchanged. The additive light pass remains RGB-only. With bloom disabled,
the original alpha blend is restored. True transparent modes retain the old
RGB-only behavior while bloom is enabled. This does not resolve all
transparent-material or postprocess-edge limitations.

The depth treatment from beta.5.4 is retained; further shockwave reduction is
not claimed in this regression fix. Quest validation is required.

Run `python tests/check-avatar-rendering.py` for 96 native/stub material cases.
Run `python tests/check-bloom-gpu.py` with UnityPy 1.25.4 and host surfaceless
EGL/GLES3 (Mesa) to check actual blend arithmetic against the serialized bundle
state. This uses minimal shaders, not MToon lighting or Quest postprocessing.
Shader reproducibility: `tools/patch-bloom-alpha.py` accepts the beta.5.4 bundle
and changes only base/outline alpha blend fields and three hidden properties;
GPU blobs, all RGB blend states and other objects are verified unchanged.

## Arm reach release (beta.5.6)

Each arm follows its controller while its target is within 120% of the avatar's
calibrated upper-arm + forearm length, measured from the upper-arm joint. Extra
stretch is capped at that same 120%, replacing the earlier 200% cap. Beyond
reach, the arm blends over approximately 0.20 s to a slightly bent relaxed pose
beside the torso. That pose follows the solved chest position and rotation.
The hands reconnect independently once the target returns within 110%; this
hysteresis prevents rapid attachment changes near the outer threshold.

Only the avatar IK target is changed: no controller or saber Transform is
written, and Beat Saber hit detection remains under the game's tracking.
The limits scale with calibration/Arm Scale, not an absolute world distance.
Match Armspans remains useful for matching the user's body proportions. Limits
are named constants in `ArmReachGuard.hpp`; no new settings or config migration
are required. Existing rendering/shader bytes from beta.5.5 are retained.

Checks: compile/run `tests/arm-reach-guard.cpp` with a host C++20 compiler;
set CXX to host-capable Clang and run `python tests/check-arm-reach-pose.py`.
The latter compiles actual Arm/BodyPart/VirtualBone methods with math and
Transform stubs. It covers both hands, shoulder/no-shoulder rigs, three scales,
release/reconnect and body motion. Neither test executes Quest or Unity.

## Crouch reach correction (beta.5.7)

beta.5.6 decided whether to release a hand during Arm::PreSolve, before the
spine/crouch solver translated the arm root. During a crouch this compared a
lowered controller against the old standing shoulder position. beta.5.7 keeps
a bounded preview for chest solving but advances the reach state only during
Arm::Solve, after the spine has solved the current chest and TranslateRoot has
positioned the arm. The 120% release / 110% reconnect limits and 0.20 s blend
are retained; the limiter is not disabled during crouching.

`tests/check-arm-reach-pose.py` now includes 9 crouch positions per rig/settings
variant, genuine excess reach while crouched, and 12 whole-body scenarios with
actual Spine, planted Leg and Arm methods. A negative control restores the
beta.5.6 call order and must reproduce the false release. These tests use host
math/Transform stubs; they do not run Unity, IL2CPP or a Quest headset.

## Arm extension tuning (beta.5.8)

Max reach/stretch is now 130% of calibrated arm length (+30%). Reconnection
occurs within 125%, keeping a 5 percentage point hysteresis gap. The 0.20 s
blend, independent hand state and beta.5.7 post-crouch decision order remain.
The Arm.cpp algorithm is unchanged from beta.5.7; constants are in
ArmReachGuard.hpp. Native pose tests include 25% extension with lowered arms.
Quest runtime testing is still required for this version.
