#include "MaterialTracker.hpp"

#include "main.hpp"
#include "MirrorManager.hpp"
#include "utils/AvatarRenderPolicy.hpp"

namespace VRMQavatars
{
    bool MaterialTracker::bloomEnabled = false;
    std::vector<SafePtrUnity<UnityEngine::Material>> MaterialTracker::materials;

    void MaterialTracker::UpdateMaterials()
    {
        VRMLogger.info("updating materials :3");
        for(auto material : materials)
        {
            VRMLogger.info("updating material");
            if(material)
            {
                VRMLogger.info("valid material {} {}", static_cast<std::string>(material->get_name()).c_str(), static_cast<std::string>(material->shader->get_name()).c_str());
                material->SetInt("_BloomSupport", bloomEnabled ? 1 : 0);
                const float blendMode = material->GetFloat("_BlendMode");
                const int mask = AvatarRenderPolicy::ColorMask(blendMode, bloomEnabled);
                material->SetInt("_ColorMask", mask);
                // MToon used BlendOp Max for alpha. It cannot erase background
                // bloom and some shader variants emit A=1 regardless of BloomSupport.
                // Clear solid alpha independently of RGB and fragment variant.
                const bool clearAlpha = AvatarRenderPolicy::ClearBloomAlpha(blendMode, bloomEnabled);
                material->SetFloat("_AvatarAlphaOp", clearAlpha ? 0.0f : 4.0f);
                material->SetFloat("_AvatarAlphaSrc", clearAlpha ? 0.0f : material->GetFloat("_SrcBlend"));
                material->SetFloat("_AvatarAlphaDst", clearAlpha ? 0.0f : material->GetFloat("_DstBlend"));
                VRMLogger.info("Avatar render mask: blend {}, bloom {}, mask {}", blendMode, bloomEnabled, mask);
            }
        }
        if(MirrorManager::mainMirror)
        {
            MirrorManager::UpdateMirror(false);
        }
    }
}
