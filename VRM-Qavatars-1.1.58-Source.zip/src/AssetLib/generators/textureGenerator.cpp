#include "AssetLib/generators/textureGenerator.hpp"

#include "AssetLib/gLTFImageReader.hpp"

#include "bsml/shared/BSML/MainThreadScheduler.hpp"

#include "UnityEngine/TextureFormat.hpp"
#include "UnityEngine/Texture2D.hpp"

#include <cstdint>
#include <functional>
#include <algorithm>
#include <stdexcept>
#include "main.hpp"

namespace AssetLib::Generators
{
    std::vector<SafePtrUnity<UnityEngine::Texture2D>> TextureGenerator::Generate(const std::vector<std::vector<uint8_t>>& images)
    {   
        std::vector<SafePtrUnity<UnityEngine::Texture2D>> retTextures;
        retTextures.reserve(images.size());

        for (size_t i = 0; i < images.size(); i++)
        {
            // ArrayW does not own a GC handle. Do not leave encoded managed
            // arrays on a native heap while another thread waits for scheduling.
            auto encoded = ArrayW<uint8_t>(images[i].size());
            std::copy(images[i].begin(), images[i].end(), encoded.begin());
            retTextures.emplace_back(UnityEngine::Texture2D::New_ctor(2, 2, UnityEngine::TextureFormat::RGBA32, false, false));
            auto texture = retTextures.back().ptr();
            if (!UnityEngine::ImageConversion::LoadImage(texture, encoded, false)) {
                VRMLogger.error("VRM texture {} failed to decode ({} bytes)", i, images[i].size());
                for (auto& decoded : retTextures) {
                    if (decoded) UnityEngine::Object::Destroy(decoded.ptr());
                }
                throw std::runtime_error("VRM texture decode failed at image " + std::to_string(i));
            }
        }

        return retTextures;
    }
}
