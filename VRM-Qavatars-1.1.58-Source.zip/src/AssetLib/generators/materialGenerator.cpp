#include "AssetLib/generators/materialGenerator.hpp"
#include "AssetLib/modelImporter.hpp"
#include "main.hpp"
#include "utils/AvatarRenderPolicy.hpp"

namespace AssetLib::Generators
{
    template<>
    UnityEngine::Material* MaterialGenerator::Generate(const VRMC_VRM_0_0::Vrm& vrm, int index, UnityEngine::Texture2D** textures)
    {
        auto [name, shader, renderQueue, floatProperties, vectorProperties, textureProperties, keywordMap, tagMap] = vrm.materialProperties[index];

        auto mat = UnityEngine::Material::New_ctor(AssetLib::ModelImporter::mtoon.ptr());

        for (const auto & [ key, value ] : floatProperties )
        {
            mat->SetFloat(key.c_str(), value);
        }

        for (const auto & [ key, value ] : keywordMap )
        {
            if(value)
            {
                mat->EnableKeyword(key.c_str());
            }
            else
            {
                mat->DisableKeyword(key.c_str());
            }

        }

        for (const auto & [ key, value ] : textureProperties )
        {
            mat->SetTexture(key.c_str(), textures[value]);
        }

        for (const auto & [ key, value ] : vectorProperties )
        {
            mat->SetColor(key.c_str(), Sombrero::FastColor(value[0], value[1], value[2], value[3]));
        }

        for (const auto & [ key, value ] : tagMap )
        {
            mat->SetOverrideTag(key, value);
        }

        int queue = static_cast<int32_t>(renderQueue);
        // The declared material mode is authoritative. Conflicting exported
        // blend/keyword/ZWrite values can leave solid shoes out of scene depth.
        const float blendMode = mat->GetFloat("_BlendMode");
        if (VRMQavatars::AvatarRenderPolicy::IsSolid(blendMode)) {
            const bool cutout = blendMode == 1.0f;
            mat->SetFloat("_ZWrite", 1.0f);
            mat->SetFloat("_SrcBlend", 1.0f); // One
            mat->SetFloat("_DstBlend", 0.0f); // Zero
            mat->DisableKeyword("_ALPHABLEND_ON");
            mat->DisableKeyword("_ALPHAPREMULTIPLY_ON");
            if (cutout) mat->EnableKeyword("_ALPHATEST_ON");
            else mat->DisableKeyword("_ALPHATEST_ON");
            mat->SetOverrideTag("RenderType", cutout ? "TransparentCutout" : "Opaque");
            queue = VRMQavatars::AvatarRenderPolicy::SolidQueue(blendMode, queue);
            VRMLogger.info("Solid depth normalized: material {}, mode {}, queue {} -> {}, ZWrite 1", index, blendMode, renderQueue, queue);
        } else {
            VRMLogger.info("Transparent depth preserved: material {}, mode {}, queue {}, ZWrite {}", index, blendMode, queue, mat->GetFloat("_ZWrite"));
        }
        mat->set_renderQueue(queue);

        return mat;
    }

    template<>
    UnityEngine::Material* MaterialGenerator::Generate(const VRMC_VRM_1_0::Vrm& vrm, int index, UnityEngine::Texture2D** textures)
    {
        //TODO: Implement VRMC_VRM_1_0::Vrm material generation
        return nullptr;
    }
}