#include "CalibrationHelper.hpp"
#include <chatplex-sdk-bs/shared/CP_SDK/UI/Components/CText.hpp>
#include <fmt/format.h>
#include <limits>

#include <UnityEngine/Time.hpp>
#include <UnityEngine/WaitForEndOfFrame.hpp>

#include "GlobalNamespace/OVRPlugin.hpp"
#include "AvatarManager.hpp"
#include "HandController.hpp"
#include "TPoseHelper.hpp"
#include "config/ConfigManager.hpp"
#include "customTypes/VRMSpringBone.hpp"
#include "utils/CalibrationMath.hpp"

namespace VRMQavatars
{
    namespace {
        SafePtrUnity<CP_SDK::UI::Components::CText> statusLabel;
        std::string calibrationStatus = "1.1.58 | Select mode, then Recalibrate";
        void SetCalibrationStatus(const std::string& value) {
            calibrationStatus = value;
            if (statusLabel) statusLabel->SetText(std::u16string(value.begin(), value.end()));
        }
    }
    void CalibrationHelper::BindStatusLabel(CP_SDK::UI::Components::CText* label) {
        statusLabel = label;
        SetCalibrationStatus(calibrationStatus);
    }

    void CalibrationHelper::PrepareContextForCalibration()
    {
        auto rootGameObject = AvatarManager::currentContext->rootGameObject->get_transform();

        for (const auto springBone : rootGameObject->GetComponentsInChildren<VRMSpringBone*>())
            springBone->set_enabled(false);

        const auto vrik = rootGameObject->GetComponent<FinalIK::VRIK*>();
        vrik->calibrating = true;
        vrik->set_enabled(false);

        rootGameObject->set_position({0.0f, 0.0f, 0.0f});
        rootGameObject->set_eulerAngles({0.0f, 0.0f, 0.0f});
        rootGameObject->set_localScale({1.0f, 1.0f, 1.0f});

        vrik->solver->FixTransforms();
        vrik->solver->Reset();
        vrik->componentInitiated = false;
        vrik->skipSolverUpdate = false;
        vrik->updateFrame = true;
        AvatarManager::targetManager->intialized = false;

        TPoseHelper::LoadPose();

        auto armScale = Config::ConfigManager::GetAvatarConfig().ArmCalibrationScale.GetValue() * (Config::ConfigManager::GetGlobalConfig().UncannyLongArmsFunnyUnderscoresReference.GetValue() ? 5.0f : 1.0f);
        auto legScale = Config::ConfigManager::GetAvatarConfig().LegCalibrationScale.GetValue();

        auto hips = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::Hips);
        auto LArm = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::LeftUpperArm);
        auto RArm = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::RightUpperArm);
        auto LLeg = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::LeftUpperLeg);
        auto RLeg = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::RightUpperLeg);

        LArm->set_localScale({armScale, LArm->localScale.y, LArm->localScale.z});
        RArm->set_localScale({armScale, RArm->localScale.y, RArm->localScale.z});
        LLeg->set_localScale({legScale, legScale, legScale});
        RLeg->set_localScale({legScale, legScale, legScale});

        auto localPos = hips->get_localPosition();
        hips->set_localPosition({localPos.x, localPos.y*legScale, localPos.z});
    }

    Sombrero::FastVector3 CalibrationHelper::GetPosition(const GlobalNamespace::OVRPlugin::Node node)
    {
        const auto pose = GlobalNamespace::OVRPlugin::GetNodePose(node, GlobalNamespace::OVRPlugin::Step::Render);
        const auto pos = Sombrero::FastVector3(pose.Position.x, pose.Position.y, -pose.Position.z);
        return pos;
    }

    float GetAvatarHeadHeight()
    {
        const auto vrik = AvatarManager::vrik;
        auto head = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::Head);
        return head->get_position().y - AvatarManager::currentContext->rootGameObject->get_transform()->get_position().y;
    }

    float GetAvatarHandDist()
    {
        const auto vrik = AvatarManager::vrik;
        auto avatarRightHandPos = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::RightHand)->get_position();
        auto avatarLeftHandPos = vrik->animator->GetBoneTransform(UnityEngine::HumanBodyBones::LeftHand)->get_position();
        const float avatarHandDist = UnityEngine::Vector3::Distance(avatarLeftHandPos, avatarRightHandPos);
        return avatarHandDist;
    }

    float GetBase(const int type)
    {
        if(type == 0)
        {
            return GetAvatarHandDist();
        }
        if(type == 1)
        {
            return GetAvatarHeadHeight();
        }
        return 1.0f;
    }

    float GetCalibrateScale(const std::optional<float> baseScale, const int type)
    {
        VRMLogger.info("scale: {} {}", baseScale.has_value(), baseScale.has_value() ? baseScale.value() : 0.0f);
        if(type == 0)
        {
            const auto leftHandPos = CalibrationHelper::GetPosition(GlobalNamespace::OVRPlugin::Node::HandLeft);
            const auto rightHandPos = CalibrationHelper::GetPosition(GlobalNamespace::OVRPlugin::Node::HandRight);
            const float avatarHandDist = baseScale.has_value() ? baseScale.value() : GetAvatarHandDist();
            const float readDist = UnityEngine::Vector3::Distance(leftHandPos, rightHandPos);
            const float scale = CalibrationMath::ScaleRatio(readDist, avatarHandDist).value_or(1.0f);
            VRMLogger.info("{} {} {}", readDist, avatarHandDist, scale);
            return scale;
        }
        if(type == 1)
        {
            const auto headPos = CalibrationHelper::GetPosition(GlobalNamespace::OVRPlugin::Node::Head);
            const float avatarHeadHeight = baseScale.has_value() ? baseScale.value() : GetAvatarHeadHeight();
            const auto ratio = CalibrationMath::ScaleRatio(headPos.y, avatarHeadHeight);
            if (!ratio) VRMLogger.error("Invalid height calibration: tracked head {}, avatar head {}", headPos.y, avatarHeadHeight);
            const float scale = ratio.value_or(std::numeric_limits<float>::quiet_NaN());
            VRMLogger.info("height calibration: head {} / avatar {} = {}", headPos.y, avatarHeadHeight, scale);
            return scale;
        }
        return Config::ConfigManager::GetGlobalConfig().FixedScale.GetValue();
    }

    void CalibrationHelper::Calibrate(const std::optional<float> scale)
    {
        auto rootGameObject = AvatarManager::currentContext->rootGameObject->get_transform();

        const auto vrik = AvatarManager::vrik;
        const auto targetManager = AvatarManager::targetManager;

        PrepareContextForCalibration();

        const float requestedScale = scale.has_value() ? scale.value() : GetCalibrateScale(std::nullopt, Config::ConfigManager::GetGlobalConfig().CalibrationType.GetValue());
        const float calibScale = CalibrationMath::IsValidScale(requestedScale) ? requestedScale : 1.0f;
        VRMLogger.info("calibration scale {}", calibScale);

        auto& avaConfig = Config::ConfigManager::GetAvatarConfig();
        avaConfig.HasCalibrated.SetValue(true);
        avaConfig.CalibratedScale.SetValue(calibScale);

        rootGameObject->set_localScale(UnityEngine::Vector3(calibScale, calibScale, calibScale));
        const float measuredHead = GetPosition(GlobalNamespace::OVRPlugin::Node::Head).y;
        const float measuredModel = GetAvatarHeadHeight();
        SetCalibrationStatus(fmt::format("1.1.58 | Head {:.2f}m | Model {:.2f}m | Scale {:.3f}",
            measuredHead, measuredModel, rootGameObject->get_localScale().y));
        VRMLogger.info("Applied calibration: tracked head {}, model head {}, requested scale {}, actual root scale {}",
            measuredHead, measuredModel, calibScale, rootGameObject->get_localScale().y);

        HandController::ApplyHandPose(vrik->animator, Config::ConfigManager::GetFingerPoseSettings().grabPose);

        vrik->solver->spine->headTarget = targetManager->headTarget->get_transform();
        vrik->solver->leftArm->target = targetManager->leftHandTarget->get_transform();
        vrik->solver->rightArm->target = targetManager->rightHandTarget->get_transform();

        vrik->calibrating = false;
        // Refresh targets in world space after changing the root scale.
        targetManager->intialized = true;
        targetManager->Update();
        vrik->Initiate();
        // Reapply the original avatar settings after the rebuilt solver exists.
        AvatarManager::UpdateVRIK();
        targetManager->intialized = true;
        vrik->set_enabled(true);
        Config::ConfigManager::SaveAvatarConfig();
        VRMLogger.info("Calibration complete: requested {}, root scale after IK initialization {}",
            calibScale, rootGameObject->get_localScale().y);

        for (const auto springBone : rootGameObject->GetComponentsInChildren<VRMSpringBone*>())
            springBone->set_enabled(true);
    }

    custom_types::Helpers::Coroutine CalibrationHelper::StartCalibrationProc(const bool fitHeight)
    {
        if (!AvatarManager::currentContext || !AvatarManager::vrik || AvatarManager::vrik->calibrating) co_return;
        // Fit Height explicitly selects height for this operation; old saved Fixed
        // or Armspan settings must not silently change the meaning of this button.
        const int type = fitHeight ? 1 : Config::ConfigManager::GetGlobalConfig().CalibrationType.GetValue();
        const char* mode = type == 0 ? "Armspan" : type == 1 ? "Height" : "Fixed";
        const auto context = AvatarManager::currentContext;
        float time = 0.0f;
        float previewScale = 1.0f;
        bool validPreview = false;
        auto rootGameObject = AvatarManager::currentContext->rootGameObject->get_transform();

        PrepareContextForCalibration();

        const float baseScale = GetBase(type);

        while(time < 4.0f)
        {
            if (AvatarManager::currentContext != context) co_return;
            time += UnityEngine::Time::get_deltaTime();

            auto headPos = GetPosition(GlobalNamespace::OVRPlugin::Node::Head);
            const auto leftHandPos = GetPosition(GlobalNamespace::OVRPlugin::Node::HandLeft);
            const auto rightHandPos = GetPosition(GlobalNamespace::OVRPlugin::Node::HandRight);

            headPos.y = 0.0f;

            const float yRotation = Sombrero::FastQuaternion::LookRotation(leftHandPos - rightHandPos, Sombrero::FastVector3::forward()).get_eulerAngles().y + 90.0f;

            rootGameObject->set_position(headPos);
            rootGameObject->set_rotation(UnityEngine::Quaternion::Euler(0.0f, yRotation, 0.0f));
            const float scale = GetCalibrateScale(baseScale, type);
            if (CalibrationMath::IsValidScale(scale)) { previewScale = scale; validPreview = true; }
            rootGameObject->set_localScale(Sombrero::FastVector3(previewScale, previewScale, previewScale));
            SetCalibrationStatus(fmt::format("1.1.58 | {} {:.0f}s | Head {:.2f}m | Scale {:.3f}",
                mode, std::max(0.0f, 4.0f - time), GetPosition(GlobalNamespace::OVRPlugin::Node::Head).y, previewScale));

            co_yield reinterpret_cast<System::Collections::IEnumerator*>(CRASH_UNLESS(UnityEngine::WaitForEndOfFrame::New_ctor()));
        }
        // Commit the scale measured against the original unscaled pose. Do not
        // remeasure a second time after the preview has changed the hierarchy.
        if (!validPreview) {
            Calibrate(Config::ConfigManager::GetAvatarConfig().CalibratedScale.GetValue());
            SetCalibrationStatus("1.1.58 | Invalid tracking height; previous scale retained");
        } else {
            Calibrate(previewScale);
            SetCalibrationStatus(fmt::format("1.1.58 | {} | Head {:.2f}m | Base {:.2f}m | Scale {:.3f}",
                mode, GetPosition(GlobalNamespace::OVRPlugin::Node::Head).y, baseScale, rootGameObject->get_localScale().y));
        }
        co_return;
    }
}
