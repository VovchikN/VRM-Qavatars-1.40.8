#!/usr/bin/env python3
"""Package freshly built ARM64 libraries using a validated QPM manifest.

Fallback for an invalid intermediate QMod archive. Never reuses a prior mod binary.
Pass --depth-test ONLY with the experimental freshly linked main library.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import os
import tempfile
import zipfile

root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--library',type=Path,default=root/'build/libvrm-qavatars.so');p.add_argument('--output',type=Path,default=root/'VRM-Qavatars-1.1.58-BS1.40.8.qmod');p.add_argument('--depth-test',action='store_true');p.add_argument('--assimp-url',help='Verified published Scotland2 Assimp asset URL');a=p.parse_args()
m=json.loads((root/'mod.json').read_text())
assert m['id']=='vrm-qavatars' and m['modloader']=='Scotland2' and m['packageVersion']=='1.40.8_7379'
assert m['version']=='1.1.58'
# Upstream Assimp download has QuestLoader metadata; require supplied Scotland2 QMod.
for dependency in m['dependencies']:
 if dependency['id']=='assimp':
  dependency.pop('downloadIfMissing',None)
  if a.assimp_url:
   assert a.assimp_url.startswith('https://github.com/VovchikN/') and '/releases/download/' in a.assimp_url and a.assimp_url.endswith('.qmod')
   dependency['downloadIfMissing']=a.assimp_url
(root/'mod.json').write_text(json.dumps(m,indent=2)+'\n')
files={'libvrm-qavatars.so':a.library,'libOVRLipSync.so':root/'OVRLipSync/libOVRLipSync.so','LICENSE':root/'LICENSE','THIRD_PARTY_NOTICES.txt':root/'THIRD_PARTY_NOTICES.txt'}
for path in sorted((root/'licenses').glob('*.txt')):files['licenses/'+path.name]=path
assert set(m['lateModFiles']+m['libraryFiles'])<=files.keys()
if a.depth_test:
 m['description']='Experimental camera-depth shader test with beta.5 IK/calibration fixes. GPU behavior unverified. Install instead of normal beta.5, never alongside it.'
a.output.parent.mkdir(parents=True,exist_ok=True)
fd,temporary=tempfile.mkstemp(prefix='qavatars-package-',suffix='.qmod');os.close(fd)
with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('mod.json',json.dumps(m,indent=2)+'\n')
 for name,path in files.items():z.write(path,name)
 if a.depth_test:z.writestr('DEPTH-TEST-NOTES.txt','Experimental camera-depth pass reuses existing compiled MToon programs, ColorMask 0, ZWrite On, LightMode ShadowCaster. Not a full shadow shader. No Quest GPU validation. Materials with renderQueue >2500 are excluded from camera depth. Same ID/version as regular beta.5: install one variant at a time. Reinstall normal beta.5 to revert.\n')
os.replace(temporary,a.output)
report={'package':a.output.name,'experimental_depth_test':a.depth_test,'runtime_tested':False,'experimental_depth_refinement':False,'arm_reach_guard':True,'manifest':m,'libraries':{}}
with zipfile.ZipFile(a.output) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for name,path in files.items():assert z.read(name)==path.read_bytes()
 for name in m['lateModFiles']+m['libraryFiles']:
  path=files[name];header=subprocess.check_output(['readelf','-h',str(path)],text=True)
  assert 'AArch64' in header and 'ELF64' in header and 'DYN' in header
  dynamic=subprocess.check_output(['readelf','-d',str(path)],text=True);assert 'TEXTREL' not in dynamic
  report['libraries'][name]={'sha256':hashlib.sha256(z.read(name)).hexdigest(),'bytes':len(z.read(name)),'elf64_aarch64':True,'no_textrel':True}
report['sha256']=hashlib.sha256(a.output.read_bytes()).hexdigest();report['bytes']=a.output.stat().st_size
(a.output.parent/(a.output.stem+'-validation.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='manifest'},indent=2))
