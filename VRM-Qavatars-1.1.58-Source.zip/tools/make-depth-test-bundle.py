#!/usr/bin/env python3
"""Build an EXPERIMENTAL camera-depth pass from existing MToon GPU programs.

Requires UnityPy==1.25.4 (or a compatible release). No shader compiler is used.
The forward programs are reused with color writes off and LightMode ShadowCaster.
This is a diagnostic Quest build, not a general-purpose shadow-map shader:
GPU loading, alpha coverage, stereo and performance MUST be tested on device.
Never overwrite the original input bundle.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import UnityPy

parser=argparse.ArgumentParser()
parser.add_argument('input',type=Path);parser.add_argument('output',type=Path)
a=parser.parse_args();assert a.input.resolve()!=a.output.resolve()
env=UnityPy.load(str(a.input)); changed=0;report={'experimental':True,'runtime_tested':False,'original_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'unitypy_version':UnityPy.__version__,'changes':[]}
original_bytes={o.path_id:o.get_raw_data() for o in env.objects}
original_passes=None;original_blob=None;shader_id=None
for obj in env.objects:
    if obj.type.name!='Shader':continue
    shader=obj.read()
    if shader.m_ParsedForm.m_Name!='VRM/MToon':continue
    shader_id=obj.path_id;original_blob=bytes(shader.compressedBlob)
    original_passes=copy.deepcopy(shader.m_ParsedForm.m_SubShaders)
    for sub in shader.m_ParsedForm.m_SubShaders:
        if any(('LIGHTMODE','SHADOWCASTER') in [(k.upper(),v.upper()) for k,v in p.m_State.m_Tags.tags] for p in sub.m_Passes):
            raise RuntimeError('Input already has a ShadowCaster pass')
        forward=next(p for p in sub.m_Passes if p.m_State.m_Name=='FORWARD_BASE')
        depth=copy.deepcopy(forward)
        depth.m_State.m_Name='QAVATARS_CAMERA_DEPTH_TEST'
        depth.m_State.m_Tags.tags=[('LIGHTMODE','SHADOWCASTER'),('RenderType','Opaque')]
        depth.m_Tags.tags=[('LIGHTMODE','SHADOWCASTER')]
        depth.m_State.zWrite.val=1.;depth.m_State.zWrite.name='<noninit>'
        depth.m_State.zTest.val=4.;depth.m_State.zTest.name='<noninit>'
        depth.m_State.alphaToMask.val=0.;depth.m_State.alphaToMask.name='<noninit>'
        for i in range(8):
            rt=getattr(depth.m_State,'rtBlend'+str(i))
            for field,value in [('srcBlend',1.),('destBlend',0.),('srcBlendAlpha',1.),('destBlendAlpha',0.),('blendOp',0.),('blendOpAlpha',0.),('colMask',0.)]:
                x=getattr(rt,field);x.val=value;x.name='<noninit>'
        depth.m_State.gpuProgramID=max(p.m_State.gpuProgramID for p in sub.m_Passes)+1
        sub.m_Passes.append(depth);changed+=1
        report['changes'].append({'shader':'VRM/MToon','old_passes':len(sub.m_Passes)-1,'new_passes':len(sub.m_Passes),'depth_pass':'QAVATARS_CAMERA_DEPTH_TEST','color_write_mask':0,'zwrite':1,'reused_gpu_programs':True})
    shader.save()
assert changed and shader_id is not None
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_bytes(env.file.save(packer='lz4'))
# Read the newly serialized bundle independently; all other objects and original
# passes/program blobs must remain exactly the same.
check=UnityPy.load(str(a.output))
for obj in check.objects:
    if obj.path_id!=shader_id:
        assert obj.get_raw_data()==original_bytes[obj.path_id],obj.path_id
    else:
        shader=obj.read();assert bytes(shader.compressedBlob)==original_blob
        for before,after in zip(original_passes,shader.m_ParsedForm.m_SubShaders):
            assert before.m_Passes==after.m_Passes[:-1]
            assert after.m_Passes[-1].m_State.zWrite.val==1
report['output_sha256']=hashlib.sha256(a.output.read_bytes()).hexdigest()
report['other_objects_byte_identical']=True;report['original_passes_and_gpu_programs_preserved']=True
(a.output.parent/'depth-bundle-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
