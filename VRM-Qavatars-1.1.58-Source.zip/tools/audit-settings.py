#!/usr/bin/env python3
"""Inventory of declared config fields and literal source references, not runtime QA."""
from pathlib import Path
import re,json,argparse
r=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
t=(r/'include/config/config.hpp').read_text();out=[]
for m in re.finditer(r'(VRM_JSON_CLASS|DECLARE_CONFIG)\((\w+)\s*,',t):
 i=m.end();start=i;depth=1
 while depth and i<len(t):depth+=(t[i]=='(')-(t[i]==')');i+=1
 b=t[start:i-1];fields=[]
 for f in re.finditer(r'(?<![\w])(?:VALUE_DEFAULT|VALUE)\(\s*([^,]+),\s*(\w+)',b):fields.append((f.group(2),f.group(1).strip()))
 for f in re.finditer(r'CONFIG_VALUE\(\s*(\w+),\s*([^,]+)',b):fields.append((f.group(1),f.group(2).strip()))
 for name,typ in fields:
  refs=[]
  for path in sorted((r/'src').rglob('*.cpp')):
   n=len(re.findall(r'\b'+re.escape(name)+r'\b',path.read_text()))
   if n:refs.append({'file':path.relative_to(r).as_posix(),'literal_occurrences':n})
  out.append({'group':m.group(2),'field':name,'type':typ,'references':refs,'note':'Legacy no-op field; UI removed, JSON retained' if name=='ForceHair' else ''})
report={'runtime_tested':False,'method':'Declared fields; lexical references only. Occurrence does not prove effective runtime behavior. Nested/reflected fields may be consumed without a literal reference.','field_count':len(out),'fields':out,'fixed':['Body Stiffness range corrected to 0..1; runtime body/shoulder weights clamped','Both shoulderRotationWeight values applied','IK reset refreshes IK controls','Lighting saturation slider refreshes from config','No immediate IK solve from settings handler','Deferred persistence with idle/exit/context-switch flush','Mirror size does not recreate same-dimension render target','Beatmap-light off applies platform fallback','Mirror idle quaternion is identity'],'unsupported':['ForceHair legacy field has no implementation; removed ineffective control, kept JSON compatibility','AniLipSync startup remains unhooked upstream','VRM1.0 material generator remains upstream TODO'],'quest_regression_required':['All UI tabs and global/per-avatar overrides','Replay and FBT combinations','Actual appearance while dragging sliders','New depth pass on real Quest']}
a.output.write_text(json.dumps(report,indent=2)+'\n');print('Declared config fields:',len(out));print('No literal references outside config:',[(f['group'],f['field']) for f in out if not f['references']])
