#!/usr/bin/env python3
"""Preserve base-pass bloom occlusion alpha against additive-light passes.
No GPU programs are modified or recompiled. Depth pass remains beta.5.3.
"""
from pathlib import Path
import argparse,copy,hashlib,json,os,tempfile
import UnityPy
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args();assert a.input.resolve()!=a.output.resolve()
e=UnityPy.load(str(a.input));before={x.path_id:x.get_raw_data() for x in e.objects};sid=None;old=None;blob=None;count=0
for obj in e.objects:
 if obj.type.name!='Shader':continue
 shader=obj.read()
 if shader.m_ParsedForm.m_Name!='VRM/MToon':continue
 sid=obj.path_id;old=copy.deepcopy(shader.m_ParsedForm.m_SubShaders);blob=bytes(shader.compressedBlob)
 for sub in shader.m_ParsedForm.m_SubShaders:
  for pas in sub.m_Passes:
   if pas.m_State.m_Name!='FORWARD_ADD':continue
   for i in range(8):
    mask=getattr(pas.m_State,'rtBlend'+str(i)).colMask;mask.name='<noninit>';mask.val=14.0
   count+=1
 shader.save()
assert count>0
fd,tmp=tempfile.mkstemp();os.close(fd);Path(tmp).write_bytes(e.file.save(packer='lz4'));os.replace(tmp,a.output)
for obj in UnityPy.load(str(a.output)).objects:
 if obj.path_id!=sid:assert before[obj.path_id]==obj.get_raw_data()
 else:
  shader=obj.read();assert blob==bytes(shader.compressedBlob)
  for orig,sub in zip(old,shader.m_ParsedForm.m_SubShaders):
   assert len(orig.m_Passes)==len(sub.m_Passes)
   for o,n in zip(orig.m_Passes,sub.m_Passes):
    if o.m_State.m_Name!='FORWARD_ADD':assert o==n
    else:
     restored=copy.deepcopy(n)
     for i in range(8):
      m=getattr(n.m_State,'rtBlend'+str(i)).colMask;assert m.name=='<noninit>' and m.val==14
      getattr(restored.m_State,'rtBlend'+str(i)).colMask=getattr(o.m_State,'rtBlend'+str(i)).colMask
     assert restored==o
r={'runtime_tested':False,'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'additive_passes_rgb_only':count,'all_gpu_programs_preserved':True,'base_outline_and_depth_passes_preserved':True,'all_other_objects_preserved':True}
a.report.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
