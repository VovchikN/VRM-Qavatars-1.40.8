#!/usr/bin/env python3
"""After qpm restore, select the accompanying LGPL header sources for rebuilding."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
target=root/'third_party/sombrero-0.1.43/shared';link=root/'extern/includes/sombrero/shared'
assert target.is_dir(),target
link.parent.mkdir(parents=True,exist_ok=True)
if link.is_symlink():link.unlink()
elif link.exists():raise SystemExit('Existing non-symlink directory; move it aside before selecting local sources: '+str(link))
link.symlink_to(target.resolve(),target_is_directory=True)
print('Using the accompanying sombrero source:',target)
