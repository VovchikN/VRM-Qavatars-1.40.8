#!/usr/bin/env python3
"""Check runtime DT_NEEDED and strong imports, not IL2CPP/Quest execution.
Pass downloaded supplier libs (SongCore/tinyxml2) with --extra-library.
"""
from pathlib import Path
import argparse,hashlib,json,re,subprocess
r=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--build',type=Path,required=True);p.add_argument('--ndk',type=Path,required=True);p.add_argument('--extra-library',type=Path,action='append',default=[]);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
libs=[x for x in (r/'extern/libs').glob('*.so') if '.debug.' not in x.name]+a.extra_library+[r/'OVRLipSync/libOVRLipSync.so',a.build/'libvrm-qavatars.so']
system=[x for x in (a.ndk/'toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/24').glob('*.so') if x.read_bytes()[:4]==b'\x7fELF']
def symbols(p):
 exp,imp=set(),set()
 for line in subprocess.check_output(['readelf','--dyn-syms','-W',str(p)],text=True).splitlines():
  f=line.split()
  if len(f)<8 or f[4] not in ['GLOBAL','WEAK']:continue
  name=f[7].split('@')[0]
  if f[6]=='UND':
   if f[4]=='GLOBAL':imp.add(name)
  elif f[5] in ['DEFAULT','PROTECTED']:exp.add(name)
 return exp,imp
providers=set();names=set(p.name for p in libs+system)
for lib in libs+system:providers.update(symbols(lib)[0])
out=[]
for lib in libs:
 needed=re.findall(r'\(NEEDED\).*?\[(.*?)\]',subprocess.check_output(['readelf','-d',str(lib)],text=True))
 out.append({'name':lib.name,'needed':needed,'missing_libraries':sorted(set(needed)-names),'unresolved_strong_symbols':sorted(symbols(lib)[1]-providers),'sha256':hashlib.sha256(lib.read_bytes()).hexdigest()})
report={'runtime_tested':False,'providers_include_api24_system_stubs':True,'libraries':out};a.output.write_text(json.dumps(report,indent=2)+'\n')
assert not any(x['missing_libraries'] or x['unresolved_strong_symbols'] for x in out)
print('Runtime closure:',len(out),'ELFs, no missing library names or strong symbol imports. Runtime ABI/load order not tested.')
