#!/usr/bin/env python3
"""Experimental conservative depth coverage. No new GPU programs are compiled.
Only the already-added depth pass changes: two-sided, slight toward-camera bias.
Color passes, textures and compiled GPU bytecode remain unchanged.
"""
from pathlib import Path
import argparse,copy,hashlib,json,os,tempfile
import UnityPy
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
assert a.input.resolve()!=a.output.resolve()
e=UnityPy.load(str(a.input));before={o.path_id:o.get_raw_data() for o in e.objects};oldpasses=None;shaderid=None;oldblob=None;count=0
for o in e.objects:
 if o.type.name!='Shader':continue
 s=o.read()
 if s.m_ParsedForm.m_Name!='VRM/MToon':continue
 shaderid=o.path_id;oldblob=bytes(s.compressedBlob);oldpasses=copy.deepcopy(s.m_ParsedForm.m_SubShaders)
 for sub in s.m_ParsedForm.m_SubShaders:
  depth=next(x for x in sub.m_Passes if x.m_State.m_Name=='QAVATARS_CAMERA_DEPTH_TEST');st=depth.m_State
  st.culling.name='<noninit>';st.culling.val=0.0 # Cull Off: no holes from one-sided parts.
  st.offsetFactor.name='<noninit>';st.offsetFactor.val=-1.0
  st.offsetUnits.name='<noninit>';st.offsetUnits.val=-1.0
  count+=1
 s.save()
assert count>0
fd,tmp=tempfile.mkstemp();os.close(fd);Path(tmp).write_bytes(e.file.save(packer='lz4'));os.replace(tmp,a.output)
check=UnityPy.load(str(a.output))
for o in check.objects:
 if o.path_id!=shaderid:assert before[o.path_id]==o.get_raw_data()
 else:
  s=o.read();assert bytes(s.compressedBlob)==oldblob
  for old,sub in zip(oldpasses,s.m_ParsedForm.m_SubShaders):
   assert len(old.m_Passes)==len(sub.m_Passes)
   for x,y in zip(old.m_Passes,sub.m_Passes):
    if x.m_State.m_Name!='QAVATARS_CAMERA_DEPTH_TEST':assert x==y
    else:
     assert y.m_State.culling.name=='<noninit>' and y.m_State.culling.val==0
     assert y.m_State.offsetFactor.val==-1 and y.m_State.offsetUnits.val==-1
     # All other depth program/state data is also exactly preserved.
     restored=copy.deepcopy(y);restored.m_State.culling=x.m_State.culling;restored.m_State.offsetFactor=x.m_State.offsetFactor;restored.m_State.offsetUnits=x.m_State.offsetUnits;assert restored==x
r={'runtime_tested':False,'experimental':True,'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'depth_passes_changed':count,'cull':'Off','offset':[-1,-1],'color_passes_byte_preserved':True,'gpu_programs_byte_preserved':True,'other_objects_byte_preserved':True,'limitations':['No real Quest GPU test','Transparent render queues remain excluded from camera depth','No guarantee that the residual below-knee distortion is caused by missing depth coverage']}
a.report.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
