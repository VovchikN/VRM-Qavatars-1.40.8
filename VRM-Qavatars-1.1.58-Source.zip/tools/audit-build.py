#!/usr/bin/env python3
"""Static ELF/subsystem checks. Does not run Beat Saber or Unity."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,zipfile,tempfile
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--build',type=Path,default=root/'build');p.add_argument('--ndk',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
build=a.build;main=build/'libvrm-qavatars.so'
def symbols(path):
 defs,imports=set(),set()
 for l in subprocess.check_output(['readelf','--dyn-syms','-W',str(path)],text=True).splitlines():
  s=l.split()
  if len(s)<8 or s[4] not in ('GLOBAL','WEAK'):continue
  name=s[7].split('@')[0]
  if s[6]=='UND':
   if s[4]=='GLOBAL':imports.add(name)
  elif s[5] in ('DEFAULT','PROTECTED'):defs.add(name)
 return defs,imports
exports,imports=symbols(main);assert {'setup','late_load'}<=exports
providers={}
libs=list((root/'extern/libs').glob('*.so'))+list((root/'OVRLipSync').glob('*.so'))+list((a.ndk/'toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/24').glob('*.so'))
for lib in libs:
 if '.debug.' in lib.name or lib.read_bytes()[:4]!=b'\x7fELF':continue
 for name in symbols(lib)[0]:providers.setdefault(name,lib.name)
unresolved=sorted(imports-providers.keys());assert not unresolved,unresolved
header=subprocess.check_output(['readelf','-h',str(main)],text=True);assert 'AArch64' in header and 'ELF64' in header
needed=lambda text:re.findall(r'\(NEEDED\).*?\[(.*?)\]',text)
dynamic=subprocess.check_output(['readelf','-d',str(main)],text=True);assert 'TEXTREL' not in dynamic
strings=subprocess.check_output(['strings',str(main)],text=True)
assert '1.1.58' in strings and 'Applied calibration: tracked head' in strings
assert '1.1.58 | {} | Head' in strings
assert 'Calibration complete: requested' in strings
assert 'Finger pose skipped: avatar Animator is not initialized' in strings
assert 'Hand pose skipped: null Animator' in strings
with zipfile.ZipFile(a.baseline) as z, tempfile.TemporaryDirectory() as tmp:
 import io
 with zipfile.ZipFile(io.BytesIO(z.read('install/VRM-Qavatars-1.40.8-beta.5.5.qmod'))) as q:
  b=q.read('libvrm-qavatars.so');old=Path(tmp)/'old.so';old.write_bytes(b)
  assert needed(dynamic)==needed(subprocess.check_output(['readelf','-d',str(old)],text=True))
  assert b!=main.read_bytes()
 assert z.read('source/assets/shaders.sbund')==(root/'assets/shaders.sbund').read_bytes()
 assert hashlib.sha256((root/'assets/shaders.sbund').read_bytes()).hexdigest()=='04499fc026a05ae2a5a6efbbc857c55ab4e11b33fdbcc8d8e90b362c42f1df47'
fullsymbols=subprocess.check_output(['nm','-C',str(build/'debug/libvrm-qavatars.so')],text=True)
checks=['VRMQavatars::FinalIK::VRIK::LateUpdate','VRMQavatars::TargetManager::Update','VRMQavatars::VRMSpringBone::FixedUpdate','VRMQavatars::MirrorManager::CreateMainMirror','AvatarSettingsViewController','VRMQavatars::VMC::VMCClient::InitClient','VRMQavatars::VMC::VMCServer::InitServer','VRMQavatars::BlendShape::BlendShapeController::Update','A64HookFunction','Hook_MainCameraHook','Hook_SaberPatch','VRMQavatars::FinalIK::IKSolverVR::Reset','VRMQavatars::FinalIK::Arm::Stretching','VRMQavatars::FinalIK::Arm::ApplyReachGuard','VRMQavatars::CalibrationHelper::BindStatusLabel']
checkresult={n:n in fullsymbols for n in checks};assert all(checkresult.values()),checkresult
asset=(root/'assets/shaders.sbund').read_bytes();assert main.read_bytes().count(asset)==1
object_count=len(list((build/'CMakeFiles/vrm-qavatars.dir').rglob('*.o')));assert object_count==65,object_count
report={'runtime_tested':False,'sha256':hashlib.sha256(main.read_bytes()).hexdigest(),'bytes':main.stat().st_size,'strong_imports':len(imports),'unresolved':unresolved,'needed':needed(dynamic),'setup_and_late_load':True,'subsystems':checkresult,'object_count':object_count,'experimental_depth_refinement':False,'arm_reach_guard':True,'max_arm_reach_ratio':1.3,'embedded_shader_sha256':hashlib.sha256(asset).hexdigest()}
a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
