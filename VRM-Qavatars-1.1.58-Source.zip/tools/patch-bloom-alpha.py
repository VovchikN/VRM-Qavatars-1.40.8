#!/usr/bin/env python3
"""beta.5.4 -> beta.5.5: independent alpha blending, no GPU code changes."""
from pathlib import Path
import argparse,copy,hashlib,json,os,tempfile
import UnityPy
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('output',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args();assert a.input.resolve()!=a.output.resolve()
assert hashlib.sha256(a.input.read_bytes()).hexdigest()=='3fa5d251449e7b76859378a29c2874b98317b13738ccba1dbb5c2595efa98401', 'Expected exact beta.5.4 input bundle'
e=UnityPy.load(str(a.input));before={o.path_id:o.get_raw_data() for o in e.objects};original=None;sid=None;changed=0
for obj in e.objects:
 if obj.type.name!='Shader':continue
 s=obj.read()
 if s.m_ParsedForm.m_Name!='VRM/MToon':continue
 original=copy.deepcopy(s.m_ParsedForm);blob=bytes(s.compressedBlob);sid=obj.path_id
 # Hidden material properties used exclusively by the fixed-function alpha blend.
 template=next(p for p in s.m_ParsedForm.m_PropInfo.m_Props if p.m_Name=='_SrcBlend')
 for name,value in [('_AvatarAlphaOp',4.),('_AvatarAlphaSrc',1.),('_AvatarAlphaDst',0.)]:
  prop=copy.deepcopy(template);prop.m_Name=name;prop.m_Description=name;prop.m_DefValue_0_=value;s.m_ParsedForm.m_PropInfo.m_Props.append(prop)
 for sub in s.m_ParsedForm.m_SubShaders:
  for pas in sub.m_Passes:
   if pas.m_State.m_Name not in ['FORWARD_BASE','FORWARD_BASE_ONLY_OUTLINE']:continue
   state=pas.m_State
   for i in range(8):
    blend=getattr(state,'rtBlend'+str(i))
    for key,name in [('blendOpAlpha','_AvatarAlphaOp'),('srcBlendAlpha','_AvatarAlphaSrc'),('destBlendAlpha','_AvatarAlphaDst')]:
     field=getattr(blend,key);field.name=name;field.val=0.
   changed+=1
 s.save()
assert changed==2
fd,tmp=tempfile.mkstemp();os.close(fd);Path(tmp).write_bytes(e.file.save(packer='lz4'));os.replace(tmp,a.output)
for obj in UnityPy.load(str(a.output)).objects:
 if obj.path_id!=sid:assert obj.get_raw_data()==before[obj.path_id]
 else:
  s=obj.read();assert bytes(s.compressedBlob)==blob
  restored=copy.deepcopy(s.m_ParsedForm);restored.m_PropInfo.m_Props=restored.m_PropInfo.m_Props[:-3]
  for oldsub,newsub in zip(original.m_SubShaders,restored.m_SubShaders):
   for old,new in zip(oldsub.m_Passes,newsub.m_Passes):
    if old.m_State.m_Name not in ['FORWARD_BASE','FORWARD_BASE_ONLY_OUTLINE']:assert new==old;continue
    for i in range(8):
     for key in ['blendOpAlpha','srcBlendAlpha','destBlendAlpha']:
      setattr(getattr(new.m_State,'rtBlend'+str(i)),key,copy.deepcopy(getattr(getattr(old.m_State,'rtBlend'+str(i)),key)))
  assert restored==original
r={'runtime_tested_on_quest':False,'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'base_and_outline_alpha_states_changed':changed,'gpu_programs_unchanged':True,'RGB_blending_and_depth_pass_unchanged':True,'additive_pass_unchanged_RGB_only':True,'other_bundle_objects_unchanged':True}
a.report.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
